import { ActionRowBuilder, ButtonBuilder, ButtonStyle, EmbedBuilder, StringSelectMenuBuilder } from "discord.js";
import { config } from "../database/index.js";

export async function backButtonConfig() {

    const button = new ActionRowBuilder()
    .addComponents(
        new ButtonBuilder()
        .setCustomId("back-config")
        .setLabel("Voltar")
        .setEmoji("1297615697588916234")
        .setStyle(ButtonStyle.Primary)
    )

    return button
}

export async function menuConfig() {

    const menu = new ActionRowBuilder()
    .addComponents(
        new StringSelectMenuBuilder()
        .setCustomId("menu-config")
        .setPlaceholder("Selecione uma opção...")
        .addOptions(
            { label: "Painel Ticket", emoji: "1299380091263913994", value: `config-ticketPanel`},
            { label: "Sistema de Abertura", emoji: "1299386650312577047", value: `config-openSystem`},
            { label: "Sistema de Pagamentos", emoji: "1299376608460804117", value: `config-payments`},
            { label: "Assistente Virtual", emoji: "1299386772890845300", value: `config-AI`},
            { label: "Horario de Atendimento", emoji: "1299387017976746095", value: `config-hours`},
            { label: "Cargos de Suporte", emoji: "1299387258289258497", value: `config-roles`},
            { label: "Logs", emoji: "1297708350804328479", value: `config-logs`},
            { label: "Mensagens", emoji: "1297615272634617949", value: `config-messages`},
        )
    )

    return menu
}

export async function embedConfigMenu({ interaction }) {

    const embed = new EmbedBuilder()
    .setTitle(`${interaction.guild.name} | Configurar Ticket`)
    .setColor(config.get("embed_color"))
    .setDescription(`> Olá ${interaction.user}, Bem-Vindo(a) ao Painel de configurações do seu ticket, no menu abaixo você encontra todas as possíveis configurações.`)

    return embed
}

