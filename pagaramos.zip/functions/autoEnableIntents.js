import 'dotenv/config';
import getApplicationId from './getApplicationId.js';

export default async function enableIntents(){
    await fetch(`https://discord.com/api/v9/applications/${await getApplicationId({ token: process.env.TOKEN })}`, {
        "headers": {
          "accept": "*/*",
          "accept-language": "pt-BR,pt;q=0.6",
          "authorization": `Bot ${process.env.TOKEN}`,
          "content-type": "application/json",
          "Referrer-Policy": "strict-origin-when-cross-origin"
        },
        "body": "{\"bot_public\":false,\"bot_require_code_grant\":false,\"flags\":11051008}",
        "method": "PATCH"
      })
      
      return true

}