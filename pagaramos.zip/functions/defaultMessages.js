import { EmbedBuilder } from "discord.js";
import { emojis } from "../database/index.js";

export async function replyMessage({ interaction, type, message, components }) {
    const embed = new EmbedBuilder()
    switch (type) {
        case "error": {
            embed.setColor("Red")
            embed.setDescription(`${emojis.get("error")} ${message}`)
            return interaction.reply({ embeds: [embed], components: components? [components] : [], ephemeral: true})
        }
        case "success": {
            embed.setColor("Green")
            embed.setDescription(`${emojis.get("success")} ${message}`)
            return interaction.reply({ embeds: [embed], components: components? [components] : [], ephemeral: true})
        }
        case "loading": {
           embed.setColor("#2b2d31")
           embed.setDescription(`${emojis.get("loading")} ${message}`)
           return interaction.reply({ embeds: [embed], components: components? [components] : [], ephemeral: true})
        }
    }
}

export async function editReplyMessage({ interaction, type, message, components }) {
    const embed = new EmbedBuilder()
    switch (type) {
        case "error": {
            embed.setColor("Red")
            embed.setDescription(`${emojis.get("error")} ${message}`)
            return interaction.editReply({ embeds: [embed], components: components? [components] : [], ephemeral: true})
        }
        case "success": {
            embed.setColor("Green")
            embed.setDescription(`${emojis.get("success")} ${message}`)
            return interaction.editReply({ embeds: [embed], components: components? [components] : [], ephemeral: true})
        }
        case "loading": {
           embed.setColor("#2b2d31")
           embed.setDescription(`${emojis.get("loading")} ${message}`)
           return interaction.editReply({ embeds: [embed], components: components? [components] : [], ephemeral: true})
        }
    }
}

export async function updateMessage({ interaction, type, message, components }) {
    const embed = new EmbedBuilder()
    switch (type) {
        case "error": {
            embed.setColor("Red")
            embed.setDescription(`${emojis.get("error")} ${message}`)
            return interaction.update({ embeds: [embed], components: components? [components] : [], ephemeral: true})
        }
        case "success": {
            embed.setColor("Green")
            embed.setDescription(`${emojis.get("success")} ${message}`)
            return interaction.update({ embeds: [embed], components: components? [components] : [], ephemeral: true})
        }
        case "loading": {
           embed.setColor("#2b2d31")
           embed.setDescription(`${emojis.get("loading")} ${message}`)
           return interaction.update({ embeds: [embed], components: components? [components] : [], ephemeral: true})
        }
    }
}

export async function followUpMessage({ interaction, type, message, components }) {
    const embed = new EmbedBuilder()
    switch (type) {
        case "error": {
            embed.setColor("Red")
            embed.setDescription(`${emojis.get("error")} ${message}`)
            return interaction.followUp({ embeds: [embed], components: components? [components] : [], ephemeral: true})
        }
        case "success": {
            embed.setColor("Green")
            embed.setDescription(`${emojis.get("success")} ${message}`)
            return interaction.followUp({ embeds: [embed], components: components? [components] : [], ephemeral: true})
        }
        case "loading": {
           embed.setColor("#2b2d31")
           embed.setDescription(`${emojis.get("loading")} ${message}`)
           return interaction.followUp({ embeds: [embed], components: components? [components] : [], ephemeral: true})
        }
    }
}