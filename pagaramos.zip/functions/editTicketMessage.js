import { EmbedBuilder } from "discord.js";
import { config, messages, tickets } from "../database/index.js";


export async function editTicketMessage({ type, interaction, staff, client }) {
    const user = await interaction.guild.members.cache.get(staff)
    const member = await client.users.fetch(tickets.get(`${interaction.channel.id}.author`))
    const msg = await interaction.channel.messages.fetch(tickets.get(`${interaction.channel.id}.message_id`))
    const embed = new EmbedBuilder(msg.embeds[0])
    
    switch (type) {
        case "new": {
            embed.setDescription(messages.get("ticket").replace(/{user}/g, member).replace(/{category}/g, tickets.get(`${interaction.channel.id}.category`)).replace(/{staffName}/g, user.user.username).replace(/{userName}/g, member.username))
            return msg.edit({ embeds: [embed] })
        }
        case "edit": {
            embed.setDescription(messages.get("ticket").replace(/{user}/g, member).replace(/{category}/g, tickets.get(`${interaction.channel.id}.category`)).replace(/{staffName}/g, user.user.username).replace(/{userName}/g, member.username))
            return msg.edit({ embeds: [embed] })
        }
    }

}