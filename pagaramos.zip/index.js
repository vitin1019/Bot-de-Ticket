import fs from 'fs';
import path from 'path';
import { Client, Collection, GatewayIntentBits } from 'discord.js';
import 'dotenv/config';
import enableIntents from './functions/autoEnableIntents.js';
import { emojis } from './database/index.js';
import axios from 'axios';


const client = new Client({
    intents: [
        GatewayIntentBits.Guilds,
        GatewayIntentBits.GuildMessages,
        GatewayIntentBits.MessageContent,
        GatewayIntentBits.GuildMembers,
        GatewayIntentBits.GuildVoiceStates
    ],
});

console.clear();

client.commands = new Collection();

const handlersPath = path.resolve('./handlers');
const eventsPath = path.resolve('./events');
const commandsPath = path.resolve('./commands');

const loadHandlers = async () => {
    const handlers = fs.readdirSync(handlersPath).filter(file => file.endsWith('.js'));
    await Promise.all(handlers.map(async file => {
        const filePath = new URL(`file://${path.resolve(handlersPath, file)}`).href;
        const { default: handler } = await import(filePath);
        await handler(client);
    }));
};

const loadEvents = async () => {
    const eventFiles = fs.readdirSync(eventsPath).filter(file => file.endsWith('.js'));
    await client.handleEvents(eventFiles, eventsPath);
};

const loadCommands = async () => {
    const commandFolders = fs.readdirSync(commandsPath);
    await client.handleCommands(commandFolders, commandsPath);
};

const token = `${process.env.TOKEN}`

const addEmoji = async (file, nameKey) => {
    try {
        const data = await fs.promises.readFile(`./emojis/${file}`, 'base64');
        const res = await axios.post(`https://discord.com/api/v9/applications/${emojis.get("BOT_ID") || process.env.BOT_ID}/emojis`, {
            image: `data:image/png;base64,${data}`,
            name: String(file).split(".")[0]
        }, {
            headers: {
                Authorization: `Bot ${token}`
            }
        });
        const emojiData = res.data;
        emojis.set(nameKey, `<a:${emojiData.name}:${emojiData.id}>`);
    } catch (err) {
    }
};

const loadEmojis = async () => {
    await addEmoji('success.gif', 'success');
    await addEmoji('error.gif', 'error');
    await addEmoji('loading.gif', 'loading');
};

(async () => {
    await enableIntents();
    await loadHandlers();
    await loadEvents();
    await loadCommands();

    await loadEmojis();

    client.login(process.env.TOKEN);
})();
