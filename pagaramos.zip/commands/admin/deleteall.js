import { SlashCommandBuilder, PermissionFlagsBits, EmbedBuilder, ActionRowBuilder, ButtonBuilder, ButtonStyle } from "discord.js";
import { config } from "../../database/index.js";
import { editReplyMessage, replyMessage } from "../../functions/defaultMessages.js";

export default {
    data: new SlashCommandBuilder()
        .setName("deletartickets")
        .setDescription('Delete TODOS os tickets')
        .setDefaultMemberPermissions(PermissionFlagsBits.Administrator),

    async execute(interaction, client) {
        // Lista de prefixos para verificar
        const prefixos = ["📂--", "📂・", "📞--", "📞・", "⛔--", "⛔・"];
        
        // Encontrar canais com os prefixos especificados
        const canaisParaDeletar = interaction.guild.channels.cache.filter(channel => 
            prefixos.some(prefix => channel.name.startsWith(prefix))
        );

        if (canaisParaDeletar.size === 0) {
            return replyMessage({ 
                interaction: interaction, 
                type: "error", 
                message: "Não foram encontrados canais com os prefixos especificados." 
            });
        }

        // Criar botões de confirmação
        const row = new ActionRowBuilder()
            .addComponents(
                new ButtonBuilder()
                    .setCustomId('confirmar_delete')
                    .setLabel('Confirmar')
                    .setStyle(ButtonStyle.Danger),
                new ButtonBuilder()
                    .setCustomId('cancelar_delete')
                    .setLabel('Cancelar')
                    .setStyle(ButtonStyle.Secondary)
            );

        // Criar embed com informações
        const embed = new EmbedBuilder()
            .setColor(config.get("embed_color"))
            .setDescription(`> Foram encontrados ${canaisParaDeletar.size} canais para deletar.\n\n**Canais:**\n${canaisParaDeletar.map(c => `• ${c.name}`).join('\n')}`)
            .setTimestamp()
            .setFooter({ text: interaction.user.username, iconURL: interaction.user.avatarURL() });

        if (config.get("title")) {
            embed.setAuthor({ name: config.get("title"), iconURL: interaction.guild.iconURL() });
        }

        // Enviar mensagem de confirmação
        const reply = await interaction.reply({ 
            embeds: [embed], 
            components: [row],
            ephemeral: true 
        });

        // Coletor para os botões
        const filter = i => i.user.id === interaction.user.id;
        const collector = reply.createMessageComponentCollector({ 
            filter, 
            time: 30000 
        });

        collector.on('collect', async i => {
            if (i.customId === 'confirmar_delete') {
                await i.deferUpdate();

                // Deletar os canais
                let deletados = 0;
                for (const canal of canaisParaDeletar.values()) {
                    try {
                        await canal.delete();
                        deletados++;
                    } catch (error) {
                        console.error(`Erro ao deletar canal ${canal.name}:`, error);
                    }
                }

                const embedFinal = new EmbedBuilder()
                    .setColor(config.get("embed_color"))
                    .setDescription(`> ✅ Foram deletados ${deletados} canais com sucesso!`)
                    .setTimestamp()
                    .setFooter({ text: interaction.user.username, iconURL: interaction.user.avatarURL() });

                if (config.get("title")) {
                    embedFinal.setAuthor({ name: config.get("title"), iconURL: interaction.guild.iconURL() });
                }

                await interaction.editReply({ 
                    embeds: [embedFinal], 
                    components: [] 
                });
            } else if (i.customId === 'cancelar_delete') {
                const embedCancelar = new EmbedBuilder()
                    .setColor(config.get("embed_color"))
                    .setDescription('> ❌ Operação cancelada com sucesso!')
                    .setTimestamp()
                    .setFooter({ text: interaction.user.username, iconURL: interaction.user.avatarURL() });

                if (config.get("title")) {
                    embedCancelar.setAuthor({ name: config.get("title"), iconURL: interaction.guild.iconURL() });
                }

                await interaction.editReply({ 
                    embeds: [embedCancelar], 
                    components: [] 
                });
            }
        });

        collector.on('end', async (collected, reason) => {
            if (reason === 'time') {
                const embedTimeout = new EmbedBuilder()
                    .setColor(config.get("embed_color"))
                    .setDescription('> ⏰ Tempo esgotado! Operação cancelada.')
                    .setTimestamp()
                    .setFooter({ text: interaction.user.username, iconURL: interaction.user.avatarURL() });

                if (config.get("title")) {
                    embedTimeout.setAuthor({ name: config.get("title"), iconURL: interaction.guild.iconURL() });
                }

                await interaction.editReply({ 
                    embeds: [embedTimeout], 
                    components: [] 
                });
            }
        });
    }
}