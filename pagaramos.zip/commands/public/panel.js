import { SlashCommandBuilder, PermissionFlagsBits, Embed, EmbedBuilder, ActionRowBuilder, ButtonBuilder, ButtonStyle, StringSelectMenuBuilder, PermissionsBitField } from "discord.js";
import { config, tickets } from "../../database/index.js";
import { editReplyMessage, replyMessage } from "../../functions/defaultMessages.js";

export default {
    data: new SlashCommandBuilder()
        .setName("painel")
        .setDescription('Comando dentro do Ticket')
        .addSubcommand(sb => sb.setName("membro").setDescription("Abre o painel de membro"))
        .addSubcommand(sb => sb.setName("staff").setDescription("Abre o painel de staff")),

    async execute(interaction, client) {

        if (interaction.options.getSubcommand() === "staff") {
            if (!tickets.get(`${interaction.channel.id}`)) {
                return replyMessage({ interaction: interaction, type: "error", message: "Este canal não é um ticket." })
            }

            const userRoles = interaction.member.roles.cache

            if (!config.get("supportRoles").some(role => userRoles.has(role))) {
                return replyMessage({ interaction: interaction, type: "error", message: "Você não possui permissão para usar este painel." })
            }

            if (tickets.get(`${interaction.channel.id}.closed`)) {
                return replyMessage({ interaction: interaction, type: "error", message: "Este ticket ja foi finalizado." })
            }

            const menu = new ActionRowBuilder()
				.addComponents(
					new StringSelectMenuBuilder()
						.setPlaceholder("Selecione uma opção")
						.setCustomId("staffTicketMenu")
						.addOptions(
							{ label: "Notificar Membro", emoji: "1299393175126933526", value: "ticketNotifyMember" },
							{ label: "Atribuir Atendimento", emoji: "1299391185500241952", value: "atribuirTicket" },
							{ label: "Criar Pagamento", emoji: "1299390315618242602", value: "newPaymentTicket" },
							{ label: "Adicionar Usuário", emoji: "1299393080339857592", value: "ticketAddUserAdmin" },
							{ label: "Remover Usuário", emoji: "1299393021317611521", value: "ticketRemoveUserAdmin" },
							{ label: "Finalizar Atendimento", emoji: "1299393563465093191", value: "ticketDeleteTicketAdmin" },
						)
				)

			const embed = new EmbedBuilder()
				.setColor(config.get("embed_color"))
				.setDescription("> Painel staff aberto com sucesso, utilize o menu abaixo para ver suas funções disponíveis.")
				.setTimestamp()
				.setFooter({ text: interaction.user.username, iconURL: interaction.user.avatarURL() })

			if (config.get("title")) {
				embed.setAuthor({ name: config.get("title"), iconURL: interaction.guild.iconURL() })
			}

			interaction.reply({ embeds: [embed], components: [menu], ephemeral: true })


        }

        if (interaction.options.getSubcommand() === "membro") {
            if (!tickets.get(`${interaction.channel.id}`)) {
                return replyMessage({ interaction: interaction, type: "error", message: "Este canal não é um ticket." })
            }

            if (interaction.user.id !== tickets.get(`${interaction.channel.id}.author`)) {
                return replyMessage({ interaction: interaction, type: "error", message: "Somente quem abriu o ticket pode usar este painel." })
            }

            if (tickets.get(`${interaction.channel.id}.closed`)) {
                return replyMessage({ interaction: interaction, type: "error", message: "Este ticket ja foi finalizado." })
            }

            const menu = new ActionRowBuilder()
                .addComponents(
                    new StringSelectMenuBuilder()
                        .setPlaceholder("Selecione uma opção")
                        .setCustomId("memberTicketMenu")
                        .addOptions(
                            { label: "Notificar Staff", emoji: "1299393175126933526", value: "ticketNotifyStaff" },
                            { label: "Adicionar Usuário", emoji: "1299393080339857592", value: "ticketAddUser" },
                            { label: "Remover Usuário", emoji: "1299393021317611521", value: "ticketRemoveUser" }
                        )
                )

            const embed = new EmbedBuilder()
                .setColor(config.get("embed_color"))
                .setDescription("> Painel membro aberto com sucesso, utilize o menu abaixo para ver suas funções disponíveis.")
                .setTimestamp()
                .setFooter({ text: interaction.user.username, iconURL: interaction.user.avatarURL() })

            if (config.get("title")) {
                embed.setAuthor({ name: config.get("title"), iconURL: interaction.guild.iconURL() })
            }

            interaction.reply({ embeds: [embed], components: [menu], ephemeral: true })

        }


    }

}