import { ActionRowBuilder, AttachmentBuilder, ButtonBuilder, ButtonStyle, ChannelSelectMenuBuilder, ChannelType, Embed, EmbedBuilder, Events, ModalBuilder, RoleSelectMenuBuilder, StringSelectMenuBuilder, TextInputBuilder, TextInputStyle, UserSelectMenuBuilder } from "discord.js";
import { backButtonConfig, embedConfigMenu, menuConfig } from "../components/configMenu.js";
import { config, messages, models, tickets } from "../database/index.js";
import { editReplyMessage, followUpMessage, replyMessage, updateMessage } from "../functions/defaultMessages.js";
import axios from "axios";
import { MercadoPagoConfig, Payment } from "mercadopago";
import Stripe from 'stripe';
import discordTranscripts from 'discord-html-transcripts';
import { createStaticPix, hasError } from 'pix-utils';
import Groq from "groq-sdk";
const groq = new Groq({ apiKey: "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" });
import fs from "fs"
import path from "path"
import { fileURLToPath } from 'url';

import { DateTime } from 'luxon';
import { editTicketMessage } from "../functions/editTicketMessage.js";
import { generateQrCode } from "../functions/generateQrCode.js";

export default {
	name: Events.InteractionCreate,
	async execute(interaction, client) {

		if (interaction.user.bot) return;

		if (interaction.isCommand()) {
			const command = client.commands.get(interaction.commandName);
			if (!command) return;
			try {
				await command.execute(interaction, interaction.client);
			} catch (error) {
				console.log(`${error}`);
			}
		}
		if (interaction.isAutocomplete()) {
			const command = interaction.client.commands.get(interaction.commandName);
			if (!command) {
				return;
			}
			try {
				await command.autocomplete(interaction);
			} catch (err) {
				console.log(err)
				return;
			}
		}

		if (interaction.isButton() && interaction.customId === "back-config") {
			return interaction.update({ embeds: [await embedConfigMenu({ interaction: interaction })], components: [await menuConfig()], ephemeral: true })
		}

		if (interaction.isStringSelectMenu() && interaction.values[0] === "config-ticketPanel") {

			const embed = new EmbedBuilder(interaction.message.embeds[0])
				.setTitle(config.get("title") ? config.get("title") : `Não configurado...`)
				.setFooter(config.get("footer") ? { text: config.get("footer"), iconURL: interaction.guild.iconURL() } : { text: "Não configurado...", iconURL: interaction.guild.iconURL() })
				.setDescription(config.get("description") ? `${config.get("description")}` : "> Use `delete` no valor do parâmetro caso deseje remover a opção.\n\nNão configurado...")
				.setColor(config.get("embed_color"))

			if (config.get("banner")) {
				embed.setImage(config.get("banner"))
			}

			const button = new ActionRowBuilder()
				.addComponents(
					new ButtonBuilder()
						.setCustomId("edit-panel-ticket")
						.setStyle(ButtonStyle.Success)
						.setLabel("Editar")
						.setEmoji("1299380091263913994")
				)

			interaction.update({ embeds: [embed], components: [button, await backButtonConfig()] })

		}

		if (interaction.isButton() && interaction.customId === "edit-panel-ticket") {
			const modal = new ModalBuilder()
				.setCustomId("edit-panel-ticket-modal")
				.setTitle("Editar Painel Ticket")
				.addComponents(
					new ActionRowBuilder()
						.addComponents(
							new TextInputBuilder()
								.setCustomId("title")
								.setValue(config.get("title") ? config.get("title") : "")
								.setLabel("TÍTULO")
								.setRequired(false)
								.setStyle(TextInputStyle.Short),
						),

					new ActionRowBuilder()
						.addComponents(
							new TextInputBuilder()
								.setCustomId("description")
								.setLabel("DESCRIÇÃO")
								.setValue(config.get("description") ? config.get("description") : "")
								.setRequired(false)
								.setStyle(TextInputStyle.Paragraph),
						),

					new ActionRowBuilder()
						.addComponents(
							new TextInputBuilder()
								.setCustomId("banner")
								.setLabel("BANNER")
								.setPlaceholder("https://...")
								.setValue(config.get("banner") ? config.get("banner") : "")
								.setRequired(false)
								.setStyle(TextInputStyle.Short),
						),

					new ActionRowBuilder()
						.addComponents(
							new TextInputBuilder()
								.setCustomId("color")
								.setLabel("COR DA EMBED")
								.setValue(config.get("embed_color") ? config.get("embed_color") : "")
								.setPlaceholder("#2b2d31")
								.setRequired(false)
								.setStyle(TextInputStyle.Short),
						),

					new ActionRowBuilder()
						.addComponents(
							new TextInputBuilder()
								.setCustomId("footer")
								.setValue(config.get("footer") ? config.get("footer") : "")
								.setLabel("RODAPÉ")
								.setRequired(false)
								.setStyle(TextInputStyle.Short),
						),
				)

			await interaction.showModal(modal)
		}

		if (interaction.isModalSubmit() && interaction.customId === "edit-panel-ticket-modal") {
			const title = interaction.fields.getTextInputValue("title")
			const description = interaction.fields.getTextInputValue("description")
			const banner = interaction.fields.getTextInputValue("banner")
			const color = interaction.fields.getTextInputValue("color")
			const footer = interaction.fields.getTextInputValue("footer")


			if (title) {

				if (title === "delete") {
					config.delete("title")
				} else {
					config.set("title", title)
				}
			}

			if (description) {
				if (description === "delete") {
					config.delete("description")
				} else {
					config.set("description", description)
				}
			}

			if (banner) {
				if (banner === "delete") {
					config.delete("banner")
				} else {
					config.set("banner", banner)
				}
			}

			if (color) {
				const hexRegex = /^#([A-Fa-f0-9]{6}|[A-Fa-f0-9]{3})$/;
				const test = hexRegex.test(color);

				if (!test) {
					return replyMessage({ interaction: interaction, type: "error", message: "A cor hexadecimal é invalida." })
				}

				config.set("embed_color", color)
			}

			if (footer) {
				if (footer === "delete") {
					config.delete("footer")
				} else {
					config.set("footer", footer)
				}
			}

			const embed = new EmbedBuilder()
				.setTitle(config.get("title") ? config.get("title") : `Não configurado...`)
				.setDescription(config.get("description") ? `${config.get("description")}` : "> Use `delete` no valor do parâmetro caso deseje remover a opção.\n\nNão configurado...")
				.setColor(config.get("embed_color"))
				.setFooter(config.get("footer") ? { text: config.get("footer"), iconURL: interaction.guild.iconURL() } : { text: "Não configurado...", iconURL: interaction.guild.iconURL() })

			if (config.get("banner")) {
				embed.setImage(config.get("banner"))
			}

			interaction.update({ embeds: [embed] })
		}

		if (interaction.isStringSelectMenu() && interaction.values[0] === "config-openSystem") {
			const embed = new EmbedBuilder(interaction.message.embeds[0])
				.setTitle(`${interaction.guild.name} | Configurar Sistema de Abertura`)
				.setDescription(`> Selecione um sistema de abertura abaixo, para configurar.`)
				.setColor(config.get("embed_color"))

			const button = new ActionRowBuilder()
				.addComponents(
					new ButtonBuilder()
						.setCustomId("config-buttonOpen")
						.setStyle(ButtonStyle.Secondary)
						.setLabel("Botão")
						.setEmoji("1299374148019290194"),
					new ButtonBuilder()
						.setCustomId("config-menuOpen")
						.setStyle(ButtonStyle.Secondary)
						.setLabel("Menu")
						.setEmoji("1299374148019290194"),
						new ButtonBuilder()
						.setCustomId("categoriaselect")
						.setStyle(ButtonStyle.Secondary)
						.setLabel("Selecionar categoria")
						.setEmoji("1299374148019290194"),
				)

			interaction.update({ embeds: [embed], components: [button, await backButtonConfig()] })
		}

		if (interaction.isButton() && interaction.customId === "config-buttonOpen") {

			config.set("buttonOpen", true)

			const embed = new EmbedBuilder(interaction.message.embeds[0])
				.setDescription(`> Utilize os botão abaixo, para personalizar o botão.`)
				.setColor(config.get("embed_color"))

			const button = new ActionRowBuilder()
				.addComponents(
					new ButtonBuilder()
						.setCustomId("change-text")
						.setStyle(ButtonStyle.Secondary)
						.setLabel("Texto")
						.setEmoji("1299380091263913994"),
					new ButtonBuilder()
						.setCustomId("change-emoji")
						.setStyle(ButtonStyle.Secondary)
						.setLabel("Emoji")
						.setEmoji("1299374148019290194"),
					new ButtonBuilder()
						.setCustomId("change-color")
						.setStyle(ButtonStyle.Secondary)
						.setLabel("Cor")
						.setEmoji("1299374507835789365"),
				)

			interaction.update({ embeds: [embed], components: [button, await backButtonConfig()] })

		}

		if (interaction.isButton() && interaction.customId.startsWith("setButtonColor-")) {
			const val = interaction.customId.split("-")[1]
			config.set("ticketButton.style", val)
			replyMessage({ interaction: interaction, type: "success", message: "Cor alterada com sucesso." })
		}

		if (interaction.isButton() && interaction.customId.startsWith("change-")) {
			const val = interaction.customId.split("-")[1]

			if (val === "color") {
				const embed = new EmbedBuilder(interaction.message.embeds[0])
					.setDescription(`> Selecione uma cor abaixo.`)

				const buttons = new ActionRowBuilder()
					.addComponents(
						new ButtonBuilder()
							.setCustomId("setButtonColor-Primary")
							.setLabel("Azul")
							.setStyle(ButtonStyle.Primary),
						new ButtonBuilder()
							.setCustomId("setButtonColor-Secondary")
							.setLabel("Cinza")
							.setStyle(ButtonStyle.Secondary),
						new ButtonBuilder()
							.setCustomId("setButtonColor-Success")
							.setLabel("Verde")
							.setStyle(ButtonStyle.Success),
						new ButtonBuilder()
							.setCustomId("setButtonColor-Danger")
							.setLabel("Vermelho")
							.setStyle(ButtonStyle.Danger),
					)

				interaction.update({ embeds: [embed], components: [buttons, await backButtonConfig()] })
			}

			if (val === "text") {
				const modal = new ModalBuilder()
					.setCustomId(interaction.customId)
					.setTitle("Editar Texto do Botão")
					.addComponents(
						new ActionRowBuilder()
							.addComponents(
								new TextInputBuilder()
									.setCustomId("text")
									.setValue(config.get("ticketButton.label") ? config.get("ticketButton.label") : "")
									.setLabel("TEXTO")
									.setRequired(true)
									.setStyle(TextInputStyle.Short),
							)
					)

				await interaction.showModal(modal)
			}

			if (val === "emoji") {
				const modal = new ModalBuilder()
					.setCustomId(interaction.customId)
					.setTitle("Editar Emoji do Botão")
					.addComponents(
						new ActionRowBuilder()
							.addComponents(
								new TextInputBuilder()
									.setCustomId("emoji")
									.setValue(config.get("ticketButton.emoji") ? config.get("ticketButton.emoji") : "")
									.setLabel("EMOJI")
									.setRequired(true)
									.setStyle(TextInputStyle.Short),
							)
					)

				await interaction.showModal(modal)
			}
		}

		if (interaction.isModalSubmit() && interaction.customId.startsWith("change-")) {
			const val = interaction.customId.split("-")[1]

			if (val === "text") {
				const text = interaction.fields.getTextInputValue("text")
				config.set("ticketButton.label", text)
				return replyMessage({ interaction: interaction, type: "success", message: "Texto do botão alterado com sucesso." })
			}

			if (val === "emoji") {
				const emoji = interaction.fields.getTextInputValue("emoji")

				const emojiRegex = /<(a:|:)[a-zA-Z0-9_]+:\d+>|[\uD800-\uDBFF][\uDC00-\uDFFF]/;
				const test = emojiRegex.test(emoji);

				if (!test) {
					return replyMessage({ interaction: interaction, type: "error", message: "O emoji inserido é invalido." })
				} else {
					config.set("ticketButton.emoji", emoji)
					replyMessage({ interaction: interaction, type: "success", message: "Emoji do botão alterado com sucesso." })
				}
			}
		}

		if (interaction.isButton() && interaction.customId === "config-menuOpen") {
			config.set("buttonOpen", false)

			const categorys = config.get('ticketMenu.categorys').map(data => `- \`${data.label}\``).join('\n')

			const embed = new EmbedBuilder(interaction.message.embeds[0])
				.setDescription(`> Utilize os botão abaixo, para adicionar/remover categorias ou editar o menu.\n\n### Placeholder\n- \`${config.get("ticketMenu.placeholder")}\`\n\n### Categorias de Atendimento\n${categorys ? categorys : "- `Nenhuma`"}`)

			const buttons = new ActionRowBuilder()
				.addComponents(
					new ButtonBuilder()
						.setCustomId("addCategoryMenu")
						.setEmoji("1299388865395691626")
						.setLabel("Adicionar")
						.setStyle(ButtonStyle.Success),
					new ButtonBuilder()
						.setCustomId("deleteCategoryMenu")
						.setEmoji("1200048923042131999")
						.setLabel("Remover")
						.setStyle(ButtonStyle.Danger),
					new ButtonBuilder()
						.setCustomId("editPlaceholderMenu")
						.setEmoji("1299380091263913994")
						.setLabel("Placeholder")
						.setStyle(ButtonStyle.Secondary),
				)

			interaction.update({ embeds: [embed], components: [buttons, await backButtonConfig()] })
		}

		if (interaction.isButton() && interaction.customId === "deleteCategoryMenu") {
			const modal = new ModalBuilder()
				.setCustomId(interaction.customId)
				.setTitle("Remover Categoria")
				.addComponents(
					new ActionRowBuilder()
						.addComponents(
							new TextInputBuilder()
								.setCustomId("name")
								.setLabel("NOME DA CATEGORIA")
								.setPlaceholder("Suporte")
								.setMaxLength(100)
								.setRequired(true)
								.setStyle(TextInputStyle.Short),
						),

				)

			await interaction.showModal(modal)
		}

		if (interaction.isModalSubmit() && interaction.customId === "deleteCategoryMenu") {
			const name = interaction.fields.getTextInputValue("name")

			const findCategorys = config.get("ticketMenu.categorys").find(res => res.label === name)

			if (!findCategorys) {
				return replyMessage({ interaction: interaction, type: "error", message: "Categoria não encontrada." })
			}

			const categorysFilter = config.get("ticketMenu.categorys").filter(res => res.label !== name)
			config.set("ticketMenu.categorys", categorysFilter)

			const categorys = config.get('ticketMenu.categorys').map(data => `- \`${data.label}\``).join('\n')

			const embed = new EmbedBuilder(interaction.message.embeds[0])
				.setDescription(`> Utilize os botão abaixo, para adicionar/remover categorias ou editar o menu.\n\n### Placeholder\n- \`${config.get("ticketMenu.placeholder")}\`\n\n### Categorias de Atendimento\n${categorys ? categorys : "- `Nenhuma`"}`)

			await interaction.update({ embeds: [embed] })

			followUpMessage({ interaction: interaction, type: "success", message: "Categoria removida com sucesso." })
		}

		if (interaction.isButton() && interaction.customId === "addCategoryMenu") {
			const modal = new ModalBuilder()
				.setCustomId(interaction.customId)
				.setTitle("Adicionar Categoria")
				.addComponents(
					new ActionRowBuilder()
						.addComponents(
							new TextInputBuilder()
								.setCustomId("name")
								.setLabel("NOME")
								.setPlaceholder("Suporte")
								.setMaxLength(100)
								.setRequired(true)
								.setStyle(TextInputStyle.Short),
						),
					new ActionRowBuilder()
						.addComponents(
							new TextInputBuilder()
								.setCustomId("description")
								.setLabel("MINI DESCRIÇÃO")
								.setMaxLength(100)
								.setRequired(false)
								.setPlaceholder("Categoria destinada a Suporte.")
								.setStyle(TextInputStyle.Short),
						),
					new ActionRowBuilder()
						.addComponents(
							new TextInputBuilder()
								.setCustomId("emoji")
								.setLabel("EMOJI")
								.setRequired(false)
								.setPlaceholder("<:emoji:1234974661666672740>")
								.setStyle(TextInputStyle.Short),
						),
				)

			await interaction.showModal(modal)
		}

		if (interaction.isModalSubmit() && interaction.customId === "addCategoryMenu") {
			const name = interaction.fields.getTextInputValue("name")
			const description = interaction.fields.getTextInputValue("description")
			const emoji = interaction.fields.getTextInputValue("emoji")

			const findCategorys = config.get("ticketMenu.categorys").find(res => res.label === name)

			if (findCategorys) {
				return replyMessage({ interaction: interaction, type: "error", message: "Esta categoria já existe." })
			}

			if (String(name).length >= 100) {
				return replyMessage({ interaction: interaction, type: "error", message: "O nome da categoria é muito grande." })
			}

			if (description) {
				if (String(description).length >= 100) {
					return replyMessage({ interaction: interaction, type: "error", message: "A descrição da categoria é muito grande." })
				}
			}

			if (emoji) {
				const emojiRegex = /<(a:|:)[a-zA-Z0-9_]+:\d+>|[\uD800-\uDBFF][\uDC00-\uDFFF]/;
				const test = emojiRegex.test(emoji);
				if (!test) {
					return replyMessage({ interaction: interaction, type: "error", message: "O emoji inserido é invalido." })
				}
			}

			config.push("ticketMenu.categorys", { label: name, ...(description && { description: description }), ...(emoji && { emoji: emoji }) })

			const categorys = config.get('ticketMenu.categorys').map(data => `- \`${data.label}\``).join('\n')

			const embed = new EmbedBuilder(interaction.message.embeds[0])
				.setDescription(`> Utilize os botão abaixo, para adicionar/remover categorias ou editar o menu.\n\n### Placeholder\n- \`${config.get("ticketMenu.placeholder")}\`\n\n### Categorias de Atendimento\n${categorys ? categorys : "- `Nenhuma`"}`)

			await interaction.update({ embeds: [embed] })

			followUpMessage({ interaction: interaction, type: "success", message: "Categoria adicionada com sucesso." })


		}

		if (interaction.isButton() && interaction.customId === "categoriaselect") {
			// Pega todas as categorias do servidor
			const guildCategories = interaction.guild.channels.cache
				.filter(channel => channel.type === ChannelType.GuildCategory)
				.map(category => ({
					label: category.name,
					value: category.id,
					description: `ID: ${category.id}`
				}));
		
			const selectMenu = new ActionRowBuilder()
				.addComponents(
					new StringSelectMenuBuilder()
						.setCustomId('selectCategoria')
						.setPlaceholder('Selecione uma categoria do servidor')
						.addOptions(guildCategories)
				);
		
			const embed = new EmbedBuilder()
				.setTitle(`${interaction.guild.name} | Seleção de Categoria`)
				.setDescription(`> Selecione a categoria onde os tickets serão criados.`)
				.setColor(config.get("embed_color"));
		
			await interaction.update({ 
				embeds: [embed], 
				components: [selectMenu, await backButtonConfig()] 
			});
		}
		
		if (interaction.isStringSelectMenu() && interaction.customId === "selectCategoria") {
			const selectedCategoryId = interaction.values[0];
			const selectedCategory = interaction.guild.channels.cache.get(selectedCategoryId);
			
			if (!selectedCategory) {
				return replyMessage({ 
					interaction: interaction, 
					type: "error", 
					message: "Categoria não encontrada." 
				});
			}
		
			// Salva a categoria selecionada na configuração
			config.set("ticketCategory", selectedCategoryId);
		
			const embed = new EmbedBuilder()
				.setTitle(`${interaction.guild.name} | Categoria Configurada`)
				.setDescription(`> Os tickets serão criados na categoria **${selectedCategory.name}**`)
				.setColor(config.get("embed_color"));
		
			const button = new ActionRowBuilder()
				.addComponents(
					new ButtonBuilder()
						.setCustomId("categoriaselect")
						.setStyle(ButtonStyle.Secondary)
						.setLabel("Alterar categoria")
						.setEmoji("1299374148019290194")
				);
		
			await interaction.update({ 
				embeds: [embed], 
				components: [button, await backButtonConfig()] 
			});
		}

		if (interaction.isButton() && interaction.customId === "editPlaceholderMenu") {
			const modal = new ModalBuilder()
				.setCustomId(interaction.customId)
				.setTitle("Editar Placeholder")
				.addComponents(
					new ActionRowBuilder()
						.addComponents(
							new TextInputBuilder()
								.setCustomId("placeholder")
								.setValue(config.get("ticketMenu.placeholder") ? config.get("ticketMenu.placeholder") : "")
								.setLabel("PLACEHOLDER")
								.setMaxLength(100)
								.setRequired(true)
								.setStyle(TextInputStyle.Short),
						)
				)

			await interaction.showModal(modal)
		}

		if (interaction.isModalSubmit() && interaction.customId === "editPlaceholderMenu") {
			const placeholder = interaction.fields.getTextInputValue("placeholder")
			await config.set("ticketMenu.placeholder", placeholder)

			const categorys = config.get('ticketMenu.categorys').map(data => `- \`${data.label}\``).join('\n')

			const embed = new EmbedBuilder(interaction.message.embeds[0])
				.setDescription(`> Utilize os botão abaixo, para adicionar/remover categorias ou editar o menu.\n\n### Placeholder\n- \`${config.get("ticketMenu.placeholder")}\`\n\n### Categorias de Atendimento\n${categorys ? categorys : "- `Nenhuma`"}`)

			await interaction.update({ embeds: [embed] })

			followUpMessage({ interaction: interaction, type: "success", message: "Placeholder alterado com sucesso." })
		}

		if (interaction.isStringSelectMenu() && interaction.values[0] === "config-payments") {
			const embed = new EmbedBuilder(interaction.message.embeds[0])
				.setDescription(`> Selecione abaixo qual gateway de pagamento que deseja configurar.`)
				.setTitle(`${interaction.guild.name} | Configurar Sistema de Pagamento`)

			const buttons = new ActionRowBuilder()
				.addComponents(
					new ButtonBuilder()
						.setCustomId("configPayment-mercadopago")
						.setLabel("Mercado Pago")
						.setEmoji("1299390237482422334")
						.setStyle(ButtonStyle.Secondary),
					new ButtonBuilder()
						.setCustomId("configPayment-stripe")
						.setLabel("Stripe")
						.setEmoji("1299390823506645084")
						.setStyle(ButtonStyle.Secondary),
					new ButtonBuilder()
						.setCustomId("configPayment-pixSemi")
						.setLabel("Pix")
						.setEmoji("1299390315618242602")
						.setStyle(ButtonStyle.Secondary),
				)

			interaction.update({ embeds: [embed], components: [buttons, await backButtonConfig()] })
		}

		if (interaction.isButton() && interaction.customId.startsWith("configPayment-")) {
			const gateway = interaction.customId.split("-")[1]

			if (gateway === "pixSemi") {
				const modal = new ModalBuilder()
					.setCustomId(interaction.customId)
					.setTitle("Configurar Pix")
					.addComponents(
						new ActionRowBuilder()
							.addComponents(
								new TextInputBuilder()
									.setCustomId("name")
									.setValue(config.get("paymentsGateway.pix_name") ? config.get("paymentsGateway.pix_name") : "")
									.setLabel("NOME COMPLETO")
									.setRequired(true)
									.setStyle(TextInputStyle.Short),
							),
						new ActionRowBuilder()
							.addComponents(
								new TextInputBuilder()
									.setCustomId("key")
									.setValue(config.get("paymentsGateway.pix_key") ? config.get("paymentsGateway.pix_key") : "")
									.setLabel("CHAVE PIX")
									.setRequired(true)
									.setStyle(TextInputStyle.Short),
							),
					)

				await interaction.showModal(modal)
			}

			if (gateway === "stripe") {
				const modal = new ModalBuilder()
					.setCustomId(interaction.customId)
					.setTitle("Configurar Stripe")
					.addComponents(
						new ActionRowBuilder()
							.addComponents(
								new TextInputBuilder()
									.setCustomId("secretKey")
									.setValue(config.get("paymentsGateway.stripe") ? config.get("paymentsGateway.stripe") : "")
									.setLabel("SECRET KEY")
									.setRequired(true)
									.setStyle(TextInputStyle.Short),
							)
					)

				await interaction.showModal(modal)
			}

			if (gateway === "mercadopago") {
				const modal = new ModalBuilder()
					.setCustomId(interaction.customId)
					.setTitle("Configurar Mercado Pago")
					.addComponents(
						new ActionRowBuilder()
							.addComponents(
								new TextInputBuilder()
									.setCustomId("token")
									.setValue(config.get("paymentsGateway.mercadopago") ? config.get("paymentsGateway.mercadopago") : "")
									.setLabel("ACCESS TOKEN")
									.setMaxLength(100)
									.setRequired(true)
									.setStyle(TextInputStyle.Short),
							)
					)

				await interaction.showModal(modal)
			}

		}

		if (interaction.isModalSubmit() && interaction.customId.startsWith("configPayment-")) {
			const gateway = interaction.customId.split("-")[1]

			if (gateway === "stripe") {
				const token = interaction.fields.getTextInputValue("secretKey")

				config.set("paymentsGateway.stripe", token)

				replyMessage({ interaction: interaction, type: "success", message: "Stripe configurado com sucesso." })
			}

			if (gateway === "mercadopago") {
				const token = interaction.fields.getTextInputValue("token")

				config.set("paymentsGateway.mercadopago", token)

				replyMessage({ interaction: interaction, type: "success", message: "Mercado Pago configurado com sucesso." })
			}

			if (gateway === "pixSemi") {
				const name = interaction.fields.getTextInputValue("name")
				const key = interaction.fields.getTextInputValue("key")

				config.set("paymentsGateway.pix_name", name.substring(0, 25))
				config.set("paymentsGateway.pix_key", key)

				replyMessage({ interaction: interaction, type: "success", message: "Pix configurado com sucesso." })
			}
		}

		if (interaction.isStringSelectMenu() && interaction.values[0] === "config-AI") {
			const embed = new EmbedBuilder(interaction.message.embeds[0])
				.setDescription(`> Selecione abaixo qual opção deseja configurar na sua Assistente Virtual.`)
				.setTitle(`${interaction.guild.name} | Configurar Assistente Virtual`)

			const buttons = new ActionRowBuilder()
				.addComponents(
					new ButtonBuilder()
						.setCustomId(`turnIA-${config.get("IA") ? "OFF" : "ON"}`)
						.setLabel(`${config.get("IA") ? "Desativar" : "Ativar"}`)
						.setEmoji("1297614691690086431")
						.setStyle(config.get("IA") ? ButtonStyle.Danger : ButtonStyle.Success),
					new ButtonBuilder()
						.setCustomId(`changeIA-prompt`)
						.setLabel(`Prompt`)
						.setEmoji("1299391875761045614")
						.setDisabled(config.get("IA") ? false : true)
						.setStyle(ButtonStyle.Secondary),
					new ButtonBuilder()
						.setCustomId(`changeIA-model`)
						.setLabel(`Modelo`)
						.setEmoji("1299386772890845300")
						.setDisabled(config.get("IA") ? false : true)
						.setStyle(ButtonStyle.Secondary),
					new ButtonBuilder()
						.setCustomId(`changeIA-temperature`)
						.setLabel(`Temperatura`)
						.setEmoji("1299374148019290194")
						.setDisabled(config.get("IA") ? false : true)
						.setStyle(ButtonStyle.Secondary),
				)

			interaction.update({ embeds: [embed], components: [buttons, await backButtonConfig()] })
		}

		if (interaction.isButton() && interaction.customId.startsWith("turnIA-")) {

			const status = interaction.customId.split("-")[1]

			if (status === "ON") {
				await config.set("IA", true)

				const buttons = new ActionRowBuilder()
					.addComponents(
						new ButtonBuilder()
							.setCustomId(`turnIA-${config.get("IA") ? "OFF" : "ON"}`)
							.setLabel(`${config.get("IA") ? "Desativar" : "Ativar"}`)
							.setEmoji("1297614691690086431")
							.setStyle(config.get("IA") ? ButtonStyle.Danger : ButtonStyle.Success),
						new ButtonBuilder()
							.setCustomId(`changeIA-prompt`)
							.setLabel(`Prompt`)
							.setEmoji("1299391875761045614")
							.setDisabled(config.get("IA") ? false : true)
							.setStyle(ButtonStyle.Secondary),
						new ButtonBuilder()
							.setCustomId(`changeIA-model`)
							.setLabel(`Modelo`)
							.setEmoji("1299386772890845300")
							.setDisabled(config.get("IA") ? false : true)
							.setStyle(ButtonStyle.Secondary),
						new ButtonBuilder()
							.setCustomId(`changeIA-temperature`)
							.setLabel(`Temperatura`)
							.setEmoji("1299374148019290194")
							.setDisabled(config.get("IA") ? false : true)
							.setStyle(ButtonStyle.Secondary),
					)

				await interaction.update({ components: [buttons, await backButtonConfig()] })

			}

			if (status === "OFF") {
				await config.set("IA", false)

				const buttons = new ActionRowBuilder()
					.addComponents(
						new ButtonBuilder()
							.setCustomId(`turnIA-${config.get("IA") ? "OFF" : "ON"}`)
							.setLabel(`${config.get("IA") ? "Desativar" : "Ativar"}`)
							.setEmoji("1297614691690086431")
							.setStyle(config.get("IA") ? ButtonStyle.Danger : ButtonStyle.Success),
						new ButtonBuilder()
							.setCustomId(`changeIA-prompt`)
							.setLabel(`Prompt`)
							.setEmoji("1299391875761045614")
							.setDisabled(config.get("IA") ? false : true)
							.setStyle(ButtonStyle.Secondary),
						new ButtonBuilder()
							.setCustomId(`changeIA-model`)
							.setLabel(`Modelo`)
							.setEmoji("1299386772890845300")
							.setDisabled(config.get("IA") ? false : true)
							.setStyle(ButtonStyle.Secondary),
						new ButtonBuilder()
							.setCustomId(`changeIA-temperature`)
							.setLabel(`Temperatura`)
							.setEmoji("1299374148019290194")
							.setDisabled(config.get("IA") ? false : true)
							.setStyle(ButtonStyle.Secondary),
					)

				await interaction.update({ components: [buttons, await backButtonConfig()] })
			}

		}

		if (interaction.isButton() && interaction.customId.startsWith("changeIA-")) {

			const val = interaction.customId.split("-")[1]

			if (val === "temperature") {
				const modal = new ModalBuilder()
					.setCustomId(interaction.customId)
					.setTitle("Alterar Temperatura")
					.addComponents(
						new ActionRowBuilder()
							.addComponents(
								new TextInputBuilder()
									.setCustomId("temperature")
									.setValue(String(config.get("temperature") ? config.get("temperature") : ""))
									.setLabel("TEMPERATURA")
									.setPlaceholder("Aleatoriedade das respostas geradas pelo modelo.")
									.setRequired(true)
									.setStyle(TextInputStyle.Short),
							)
					)

				await interaction.showModal(modal)
			}

			if (val === "prompt") {
				const modal = new ModalBuilder()
					.setCustomId(interaction.customId)
					.setTitle("Alterar Prompt")
					.addComponents(
						new ActionRowBuilder()
							.addComponents(
								new TextInputBuilder()
									.setCustomId("prompt")
									.setValue(config.get("prompt") ? config.get("prompt") : "")
									.setLabel("PROMPT")
									.setRequired(true)
									.setStyle(TextInputStyle.Paragraph),
							)
					)

				await interaction.showModal(modal)
			}

			if (val === "model") {
				const allmodels = await models.get("models").map(res => ({ label: res.label, description: res.description, emoji: res.emoji, value: `setModel_${res.label}` }))

				const embed = new EmbedBuilder(interaction.message.embeds[0])
					.setDescription(`> Selecione abaixo um modelo de IA, para responder seus ticket.`)

				const menu = new ActionRowBuilder()
					.addComponents(
						new StringSelectMenuBuilder()
							.setCustomId("changeModelAI")
							.setPlaceholder("Selecione um modelo")
							.addOptions(allmodels)
					)

				interaction.update({ embeds: [embed], components: [menu, await backButtonConfig()] })

			}
		}

		if (interaction.isModalSubmit() && interaction.customId === "changeIA-temperature") {
			const temperature = interaction.fields.getTextInputValue("temperature")

			if (isNaN(temperature)) {
				return replyMessage({ interaction: interaction, type: "error", message: "A temperatura inserida é inválida." })
			}

			if (Number(temperature) > 2 || Number(temperature) < 0) {
				return replyMessage({ interaction: interaction, type: "error", message: "A temperatura deve estar entre 0 e 2." })
			}

			config.set("temperature", Number(temperature))
			replyMessage({ interaction: interaction, type: "success", message: "Temperatura alterada com sucesso." })
		}

		if (interaction.isModalSubmit() && interaction.customId === "changeIA-prompt") {
			const prompt = interaction.fields.getTextInputValue("prompt")
			config.set("prompt", prompt)
			replyMessage({ interaction: interaction, type: "success", message: "Prompt alterado com sucesso." })
		}

		if (interaction.isStringSelectMenu() && interaction.values[0].startsWith("setModel_")) {
			const newModel = interaction.values[0].split("_")[1]
			config.set("model", newModel)
			await interaction.update({})
			followUpMessage({ interaction: interaction, type: "success", message: "Modelo alterado com sucesso." })
		}

		if (interaction.isStringSelectMenu() && interaction.values[0] === "config-hours") {

			const modal = new ModalBuilder()
				.setCustomId("configHours")
				.setTitle("Configurar Horário de Atendimento")
				.addComponents(
					new ActionRowBuilder()
						.addComponents(
							new TextInputBuilder()
								.setCustomId("startTime")
								.setLabel("INÍCIO DO ATENDIMENTO")
								.setPlaceholder("24:00")
								.setRequired(true)
								.setStyle(TextInputStyle.Short),
						),
					new ActionRowBuilder()
						.addComponents(
							new TextInputBuilder()
								.setCustomId("endTime")
								.setLabel("FINAL DO ATENDIMENTO")
								.setPlaceholder("24:00")
								.setRequired(true)
								.setStyle(TextInputStyle.Short),
						),
				)

			await interaction.showModal(modal)

		}

		if (interaction.isModalSubmit() && interaction.customId === "configHours") {
			const startTime = interaction.fields.getTextInputValue("startTime")
			const endTime = interaction.fields.getTextInputValue("endTime")

			await interaction.update({})

			if (startTime === "24:00" && endTime === "24:00") {
				config.delete("openingHours")
				return followUpMessage({ interaction: interaction, type: "success", message: "Horário de atendimento alterado com sucesso." })
			}

			function validarHorario(horario) {
				const regex = /^(?:[0-9]|0[0-9]|1[0-9]|2[0-3]):[0-5][0-9]$/;
				return regex.test(horario);
			}

			if (!validarHorario(startTime) || !validarHorario(endTime)) {
				return followUpMessage({ interaction: interaction, type: "error", message: "Formato do horário invalido." })
			}

			config.set("openingHours.start", startTime)
			config.set("openingHours.end", endTime)
			followUpMessage({ interaction: interaction, type: "success", message: "Horário de atendimento alterado com sucesso." })
		}

		if (interaction.isStringSelectMenu() && interaction.values[0] === "config-roles") {
			const embed = new EmbedBuilder(interaction.message.embeds[0])
				.setDescription(`> Selecione os cargos que poderão atender os ticket.`)
				.setTitle(`${interaction.guild.name} | Configurar Cargos`)

			const menu = new ActionRowBuilder()
				.addComponents(
					new RoleSelectMenuBuilder()
						.setCustomId("setRolesSupport")
						.setPlaceholder("Selecione os cargos")
						.setMaxValues(10)
				)

			interaction.update({ embeds: [embed], components: [menu, await backButtonConfig()] })
		}

		if (interaction.isRoleSelectMenu() && interaction.customId === "setRolesSupport") {
			const roles = interaction.values
			config.set("supportRoles", roles)

			replyMessage({ interaction: interaction, type: "success", message: "Cargos alterados com sucesso." })
		}

		if (interaction.isStringSelectMenu() && interaction.values[0] === "config-logs") {
			const embed = new EmbedBuilder(interaction.message.embeds[0])
				.setDescription(`> Selecione qual opção deseja configurar abaixo.`)
				.setTitle(`${interaction.guild.name} | Configurar Logs`)

			const menu = new ActionRowBuilder()
				.addComponents(
					new ButtonBuilder()
						.setCustomId("configLogs-ticket")
						.setLabel("Atendimentos")
						.setEmoji("1299391185500241952")
						.setStyle(ButtonStyle.Secondary),
					new ButtonBuilder()
						.setCustomId("configLogs-feedback")
						.setLabel("Avaliações")
						.setEmoji("1297646186244866148")
						.setStyle(ButtonStyle.Secondary),
				)

			interaction.update({ embeds: [embed], components: [menu, await backButtonConfig()] })
		}

		if (interaction.isButton() && interaction.customId.startsWith("configLogs-")) {
			const val = interaction.customId.split("-")[1]

			if (val === "feedback") {
				const embed = new EmbedBuilder(interaction.message.embeds[0])
					.setDescription(`> Selecione o canal onde deseja enviar as logs de avaliações do atendimento.`)

				const menu = new ActionRowBuilder()
					.addComponents(
						new ChannelSelectMenuBuilder()
							.setCustomId("setChannelLogFeedback")
							.setPlaceholder("Selecione um canal")
							.setChannelTypes(ChannelType.GuildText)
					)

				interaction.update({ embeds: [embed], components: [menu, await backButtonConfig()] })
			}

			if (val === "ticket") {
				const embed = new EmbedBuilder(interaction.message.embeds[0])
					.setDescription(`> Selecione o canal onde deseja enviar as logs após um atendimento for finalizado.`)

				const menu = new ActionRowBuilder()
					.addComponents(
						new ChannelSelectMenuBuilder()
							.setCustomId("setChannelLogTicket")
							.setPlaceholder("Selecione um canal")
							.setChannelTypes(ChannelType.GuildText)
					)

				interaction.update({ embeds: [embed], components: [menu, await backButtonConfig()] })
			}

		}

		if (interaction.isChannelSelectMenu() && interaction.customId.startsWith("setChannelLog")) {
			const val = interaction.customId.split("setChannelLog")[1]

			if (val === "Ticket") {
				const channel = interaction.values[0]
				config.set(`logs.atendimentos`, channel)
				replyMessage({ interaction: interaction, type: "success", message: "Canal alterado com sucesso." })
			}

			if (val === "Feedback") {
				const channel = interaction.values[0]
				config.set(`logs.feedbacks`, channel)
				replyMessage({ interaction: interaction, type: "success", message: "Canal alterado com sucesso." })
			}
		}

		if (interaction.isStringSelectMenu() && interaction.values[0] === "config-messages") {
			const embed = new EmbedBuilder(interaction.message.embeds[0])
				.setDescription(`> Selecione qual mensagem deseja configurar.`)
				.setTitle(`${interaction.guild.name} | Configurar Mensagens`)

			const menu = new ActionRowBuilder()
				.addComponents(
					new StringSelectMenuBuilder()
						.setCustomId("configMessages")
						.setPlaceholder("Selecione uma opção")
						.addOptions(
							{ label: "Ticket", emoji: "1299380091263913994", value: "configMessage-ticket" },
							{ label: "Notificação Assumir Atendimento", emoji: "1299380091263913994", value: "configMessage-assumir" },
							{ label: "Notificação Atribuir Atendimento", emoji: "1299380091263913994", value: "configMessage-atribuir" },
							{ label: "Notificação Staff", emoji: "1299380091263913994", value: "configMessage-staffNotification" },
							{ label: "Notificação Membro", emoji: "1299380091263913994", value: "configMessage-memberNotification" },
							{ label: "Feedback", emoji: "1299380091263913994", value: "configMessage-feedback" },
						)
				)

			interaction.update({ embeds: [embed], components: [menu, await backButtonConfig()] })
		}

		if (interaction.isStringSelectMenu() && interaction.values[0].startsWith("configMessage-")) {
			const val = interaction.values[0].split("-")[1]

			const button = new ActionRowBuilder()
				.addComponents(
					new ButtonBuilder()
						.setCustomId(`setNewMessage-${val}`)
						.setLabel("Alterar Mensagem")
						.setEmoji("1299374148019290194")
						.setStyle(ButtonStyle.Success),
					new ButtonBuilder()
						.setCustomId(`previewMessage-${val}`)
						.setLabel("Preview")
						.setEmoji("1259320795914698773")
						.setStyle(ButtonStyle.Secondary),
				)

			if (val === "feedback") {
				const embed = new EmbedBuilder(interaction.message.embeds[0])
					.setDescription(`> Clique no botão abaixo para alterar a mensagem.`)

				interaction.update({ embeds: [embed], components: [button, await backButtonConfig()] })
			}

			if (val === "atribuir") {
				const embed = new EmbedBuilder(interaction.message.embeds[0])
					.setDescription(`> Clique no botão abaixo para alterar a mensagem.\n\n### Variáveis\n- \`{user}\` - Menciona o usuário que vai receber a posse do atendimento\n- \`{staff}\` - Menciona o staff que vai estar passando a posse do atendimento\n`)

				interaction.update({ embeds: [embed], components: [button, await backButtonConfig()] })
			}

			if (val === "memberNotification") {
				const embed = new EmbedBuilder(interaction.message.embeds[0])
					.setDescription(`> Clique no botão abaixo para alterar a mensagem.\n\n### Variáveis\n- \`{user}\` - Menciona o usuário que abriu o ticket\n- \`{staff}\` - Menciona o staff que assumiu o atendimento\n`)

				interaction.update({ embeds: [embed], components: [button, await backButtonConfig()] })
			}

			if (val === "staffNotification") {
				const embed = new EmbedBuilder(interaction.message.embeds[0])
					.setDescription(`> Clique no botão abaixo para alterar a mensagem.\n\n### Variáveis\n- \`{user}\` - Menciona o usuário que abriu o ticket\n- \`{staff}\` - Menciona o staff que assumiu o atendimento\n`)

				interaction.update({ embeds: [embed], components: [button, await backButtonConfig()] })
			}

			if (val === "assumir") {
				const embed = new EmbedBuilder(interaction.message.embeds[0])
					.setDescription(`> Clique no botão abaixo para alterar a mensagem.\n\n### Variáveis\n- \`{user}\` - Menciona o usuário que abriu o ticket\n- \`{staff}\` - Menciona o staff que assumiu o atendimento\n`)

				interaction.update({ embeds: [embed], components: [button, await backButtonConfig()] })
			}

			if (val === "ticket") {
				const embed = new EmbedBuilder(interaction.message.embeds[0])
					.setDescription(`> Clique no botão abaixo para alterar a mensagem.\n\n### Variáveis\n- \`{user}\` - Menciona o usuário que abriu o ticket\n- \`{userName}\` - Nome do usuário que abriu o ticket\n- \`{category}\` - Categoria do atendimento\n- \`{staffName}\` - Nome do staff que assumiu o atendimento\n`)

				interaction.update({ embeds: [embed], components: [button, await backButtonConfig()] })
			}
		}

		if (interaction.isButton() && interaction.customId.startsWith("previewMessage-")) {
			const val = interaction.customId.split("-")[1]
			const embed = new EmbedBuilder()
				.setColor(config.get("embed_color"))
				.setDescription(messages.get(`${val}`))

			interaction.reply({ embeds: [embed], ephemeral: true })
		}

		if (interaction.isButton() && interaction.customId.startsWith("setNewMessage-")) {
			const modal = new ModalBuilder()
				.setCustomId(interaction.customId)
				.setTitle("Configurar Mensagem")
				.addComponents(
					new ActionRowBuilder()
						.addComponents(
							new TextInputBuilder()
								.setCustomId("message")
								.setLabel("MENSAGEM")
								.setValue(messages.get(`${interaction.customId.split("-")[1]}`))
								.setRequired(true)
								.setStyle(TextInputStyle.Paragraph),
						)
				)

			await interaction.showModal(modal)

		}

		if (interaction.isModalSubmit() && interaction.customId.startsWith("setNewMessage-")) {
			const val = interaction.customId.split("-")[1]
			const newMessage = interaction.fields.getTextInputValue("message")

			messages.set(`${val}`, newMessage)

			replyMessage({ interaction: interaction, type: "success", message: "Mensagem alterada com sucesso." })
		}

		if (interaction.isButton() && interaction.customId === "exitTicket") {
			if (interaction.user.id !== tickets.get(`${interaction.channel.id}.author`)) {
				return replyMessage({ interaction: interaction, type: "error", message: "Somente quem abriu o ticket pode sair." })
			}

			const buttons = new ActionRowBuilder()
				.addComponents(
					new ButtonBuilder()
						.setCustomId("exitTicket")
						.setLabel("Sair do Ticket")
						.setEmoji("1299392622833438833")
						.setDisabled(true)
						.setStyle(ButtonStyle.Danger),
					new ButtonBuilder()
						.setCustomId("memberPanel")
						.setLabel("Painel Membro")
						.setEmoji("1299392703439704175")
						.setDisabled(true)
						.setStyle(ButtonStyle.Secondary),
					new ButtonBuilder()
						.setCustomId("adminPanel")
						.setLabel("Painel Staff")
						.setDisabled(true)
						.setEmoji("1297614917158965349")
						.setStyle(ButtonStyle.Secondary),
				)

			await interaction.update({ components: [buttons] })
			await tickets.set(`${interaction.channel.id}.closed`, true)

			await interaction.channel.members.remove(interaction.user.id)
			await interaction.channel.setName("🔴 Atendimento finalizado!")

			const embed = new EmbedBuilder()
				.setColor(config.get("embed_color"))
				.setDescription(`> O membro ${interaction.user} saiu do atendimento, clique no botão abaixo para finalizar este ticket.`)
				.setFooter({ text: interaction.user.username, iconURL: interaction.user.avatarURL() })
				.setTimestamp()

			if (config.get("title")) {
				embed.setAuthor({ name: config.get("title"), iconURL: interaction.guild.iconURL() })
			}

			const button = new ActionRowBuilder()
				.addComponents(
					new ButtonBuilder()
						.setCustomId("deleteTicket")
						.setLabel("Finalizar Ticket")
						.setEmoji("1299374901928394793")
						.setStyle(ButtonStyle.Danger)
				)

			interaction.channel.send({ embeds: [embed], components: [button] })


		}

		if (interaction.isButton() && interaction.customId.startsWith("sendTicketFeedback-")) {

			if (!tickets.get(`${interaction.customId.split("-")[1]}`)) {
				return replyMessage({ interaction: interaction, type: "error", message: "Esse atendimento ja foi finalizado." })
			}

			if (tickets.get(`${interaction.customId.split("-")[1]}.feedback`)) {
				return replyMessage({ interaction: interaction, type: "error", message: "Esse atendimento ja foi avaliado." })
			}

			const modal = new ModalBuilder()
				.setCustomId(interaction.customId)
				.setTitle("Avaliar Atendimento")
				.addComponents(
					new ActionRowBuilder()
						.addComponents(
							new TextInputBuilder()
								.setCustomId("nota")
								.setLabel("NOTA")
								.setPlaceholder("1 a 5")
								.setRequired(true)
								.setStyle(TextInputStyle.Short),
						),
					new ActionRowBuilder()
						.addComponents(
							new TextInputBuilder()
								.setCustomId("description")
								.setLabel("COMENTARIO (OPCIONAL)")
								.setRequired(false)
								.setStyle(TextInputStyle.Paragraph),
						),
				)

			await interaction.showModal(modal)

		}

		if (interaction.isModalSubmit() && interaction.customId.startsWith("sendTicketFeedback-")) {	
			const channelId = interaction.customId.split("-")[1];
			const nota = interaction.fields.getTextInputValue("nota");
			const description = interaction.fields.getTextInputValue("description");
			const stars = "⭐";
		
			if (isNaN(nota)) {
				return replyMessage({ interaction: interaction, type: "error", message: "Nota inválida." });
			}
		
			if (nota > 5 || nota < 1) {
				return replyMessage({ interaction: interaction, type: "error", message: "Nota inválida." });
			}
		
			const feedbackChannelId = config.get("logs.feedbacks");
			const channel = await client.channels.cache.get(feedbackChannelId);
		
			if (!channel) {
				return replyMessage({ interaction: interaction, type: "error", message: "Canal de feedback não encontrado." });
			}
		
			const embed = new EmbedBuilder()
				.setColor(config.get("embed_color"))
				.setDescription(`${description ? `> ${description}\n\n` : ""}- 👤 **Aberto por:** ${interaction.user}\n- 🛠 **Atendido por:** ${tickets.get(`${channelId}.assumido`) ? `<@${tickets.get(`${channelId}.staff`)}>` : "`Ninguém`"}\n- 📁 **Categoria:** \`${tickets.get(`${channelId}.category`)}\`\n- ⭐ **Nota:** \`${stars.repeat(nota)} (${nota})\``)
				.setTimestamp()
				.setFooter({ text: interaction.user.username, iconURL: interaction.user.avatarURL() });
		
			if (config.get("title")) {
				embed.setAuthor({ name: config.get("title"), iconURL: channel.guild.iconURL() });
			}
		
			if (tickets.get(`${channelId}.feedback`)) {
				return;
			} else {
				channel.send({ embeds: [embed] }).then(r => {
					tickets.set(`${channelId}.feedback`, true);
					return replyMessage({ interaction: interaction, type: "success", message: "Avaliação enviada com sucesso." });
				}).catch(err => {
					console.error(`Error sending message to channel: ${err}`);
					return replyMessage({ interaction: interaction, type: "error", message: "Erro ao enviar avaliação." });
				});
			}
		}
	
		

		const __filename = fileURLToPath(import.meta.url);
		const __dirname = path.dirname(__filename);
		
		if (interaction.isButton() && interaction.customId === "deleteTicket" || interaction.isStringSelectMenu() && interaction.values[0] === "ticketDeleteTicketAdmin") {
			const userRoles = interaction.member.roles.cache;
		
			if (!config.get("supportRoles").some(role => userRoles.has(role))) {
				return replyMessage({ interaction: interaction, type: "error", message: "Você não possui permissão para finalizar este ticket." });
			}
		
			const channelId = interaction.channel.id;
		
			await updateMessage({ interaction: interaction, type: "loading", message: "Finalizando atendimento, por favor aguarde..." });
		
			const member = await client.users.fetch(tickets.get(`${interaction.channel.id}.author`));
		
			const transcript = await discordTranscripts.createTranscript(interaction.channel, {
				limit: -1,
				returnType: 'buffer',
				saveImages: true,
				footerText: `https://discord.gg/skyapps`,
				poweredBy: false
			});
		
			const filePath = path.join(__dirname, 'scripts', `downloadTranscript-${channelId}.html`);
			fs.writeFileSync(filePath, transcript, 'utf8');
		
			if (config.get("logs.atendimentos")) {
				const channel = await client.channels.cache.get(config.get("logs.atendimentos"));
		
				const buttonsLogs = new ActionRowBuilder()
					.addComponents(
						new ButtonBuilder()
							.setLabel("Manutenção")
							.setEmoji("1259320795914698773")
							.setDisabled(true)
							.setURL("https://discord.gg/skyapps")
							.setStyle(ButtonStyle.Link),
						new ButtonBuilder()
							.setCustomId(`downloadTranscript-${channelId}`)
							.setLabel("Baixar Transcript")
							.setEmoji("1299377396293828649")
							.setStyle(ButtonStyle.Success)
					);
		
				const embed = new EmbedBuilder()
					.setColor(config.get("embed_color"))
					.setDescription(`> **AVISO:** este transcript será deletado após 24 Horas.\n\n- 👤 **Aberto por:** <@${tickets.get(`${channelId}.author`)}>\n- ⛔ **Fechado por:** ${interaction.user}\n- 🛠 **Atendido por:** ${tickets.get(`${channelId}.assumido`) ? `<@${tickets.get(`${channelId}.staff`)}>` : "`Ninguém`"}\n- 📁 **Categoria:** \`${tickets.get(`${channelId}.category`)}\``)
					.setTimestamp()
					.setFooter({ text: member.username, iconURL: member.avatarURL() });
		
				if (config.get("title")) {
					embed.setAuthor({ name: config.get("title"), iconURL: interaction.guild.iconURL() });
				}
		
				channel.send({ embeds: [embed], components: [buttonsLogs] }).catch(err => {
					return;
				});
			}
		
			if (config.get("logs.feedbacks")) {
				const embed = new EmbedBuilder()
					.setColor(config.get("embed_color"))
					.setDescription(messages.get("feedback"))
					.setFooter({ text: "Essa avaliação expira em 1 minuto..." });
		
				if (config.get("title")) {
					embed.setAuthor({ name: config.get("title"), iconURL: interaction.guild.iconURL() });
				}
		
				const button2 = new ActionRowBuilder()
					.addComponents(
						new ButtonBuilder()
							.setCustomId(`sendTicketFeedback-${channelId}`)
							.setLabel("Avaliar Atendimento")
							.setEmoji("1299395099842707547")
							.setStyle(ButtonStyle.Success)
					);
		
				member.send({ embeds: [embed], components: [button2] }).then(async msg => {
					setTimeout(() => {
						embed.setFooter({ text: "Essa avaliação expirou." });
						button2.components[0].setDisabled(true);
						msg.edit({ components: [button2], embeds: [embed] });
						tickets.delete(`${channelId}`);
					}, 60000);
				}).catch(err => {
					tickets.delete(`${channelId}`);
					return;
				});
			} else {
				tickets.delete(`${channelId}`);
			}
		
			interaction.channel.delete();
		}
		


		if (interaction.isButton() && interaction.customId.startsWith("downloadTranscript-")) {
			const channelId = interaction.customId.split("-")[1];
			const userRoles = interaction.member.roles.cache;
		
			if (!config.get("supportRoles").some(role => userRoles.has(role))) {
				return replyMessage({ interaction: interaction, type: "error", message: "Você não possui permissão para salvar este transcript." });
			}
		
			const embed = new EmbedBuilder(interaction.message.embeds[0]);
			embed.setDescription(interaction.message.embeds[0].data.description.replace("> **AVISO:** este transcript será deletado após 24 Horas.", ""));
		
			const filePath = path.join(__dirname, 'scripts', `downloadTranscript-${channelId}.html`);
		
			if (fs.existsSync(filePath)) {
				const fileBuffer = fs.readFileSync(filePath);
		
				const attachment = new AttachmentBuilder(fileBuffer, { name: `${channelId}.html` });
		
				interaction.user.send({ embeds: [embed], files: [attachment] })
					.then(() => {
						replyMessage({ interaction: interaction, type: "success", message: "Transcript foi enviado na sua DM." });
					})
					.catch(err => {
						replyMessage({ interaction: interaction, type: "error", message: "Sua DM está bloqueada." });
					});
			} else {
				replyMessage({ interaction: interaction, type: "error", message: "Este transcript foi deletado ou não existe." });
			}
		}

		if (interaction.isButton() && interaction.customId === "memberPanel") {

			if (interaction.user.id !== tickets.get(`${interaction.channel.id}.author`)) {
				return replyMessage({ interaction: interaction, type: "error", message: "Você não possui permissão para realizar essa ação." })
			}

			const menu = new ActionRowBuilder()
				.addComponents(
					new StringSelectMenuBuilder()
						.setPlaceholder("Selecione uma opção")
						.setCustomId("memberTicketMenu")
						.addOptions(
							{ label: "Notificar Staff", emoji: "1299393175126933526", value: "ticketNotifyStaff" },
							{ label: "Adicionar Usuário", emoji: "1299393080339857592", value: "ticketAddUser" },
							{ label: "Remover Usuário", emoji: "1299393021317611521", value: "ticketRemoveUser" }
						)
				)

			const embed = new EmbedBuilder()
				.setColor(config.get("embed_color"))
				.setDescription("> Painel membro aberto com sucesso, utilize o menu abaixo para ver suas funções disponíveis.")
				.setTimestamp()
				.setFooter({ text: interaction.user.username, iconURL: interaction.user.avatarURL() })

			if (config.get("title")) {
				embed.setAuthor({ name: config.get("title"), iconURL: interaction.guild.iconURL() })
			}

			interaction.reply({ embeds: [embed], components: [menu], ephemeral: true })
		}

		if (interaction.isUserSelectMenu() && interaction.customId === "addUserMenu") {
			const userId = interaction.values[0]
			const member = await client.users.fetch(userId)

			if (tickets.get(`${interaction.channel.id}.author`) === member.id) {
				return updateMessage({ interaction: interaction, type: "error", message: "Você não pode adicionar você mesmo ao atendimento." })
			}

			if (tickets.get(`${interaction.channel.id}.members`).includes(member.id)) {
				return updateMessage({ interaction: interaction, type: "error", message: "Este usuário já está na lista de membros do atendimento." })
			}

			if (member.bot) {
				return updateMessage({ interaction: interaction, type: "error", message: "Você não pode adicionar um bot ao atendimento." })
			}

			if (member.system) {
				return updateMessage({ interaction: interaction, type: "error", message: "Você não pode adicionar um sistema ao atendimento." })
			}

			const embed = new EmbedBuilder()
				.setColor(config.get("embed_color"))
				.setDescription(`> O membro ${interaction.user} deseja adicionar ${member} a este atendimento, utilize os botão a baixo, para aprovar ou recusar este pedido.`)
				.setTimestamp()
				.setThumbnail(member.avatarURL())
				.setFooter({ text: interaction.user.username, iconURL: interaction.user.avatarURL() })

			if (config.get("title")) {
				embed.setAuthor({ name: config.get("title"), iconURL: interaction.guild.iconURL() })
			}

			const buttons = new ActionRowBuilder()
				.addComponents(
					new ButtonBuilder()
						.setCustomId(`approveTicket-${member.id}`)
						.setLabel("Aprovar")
						.setEmoji("1299393327510196244")
						.setStyle(ButtonStyle.Success),
					new ButtonBuilder()
						.setCustomId(`declineTicket-${member.id}`)
						.setLabel("Recusar")
						.setEmoji("1299378135674126376")
						.setStyle(ButtonStyle.Danger),
				)

			await interaction.channel.send({ embeds: [embed], components: [buttons] })

			updateMessage({ interaction: interaction, type: "success", message: "Solicitação para adicionar o usuário foi enviada com sucesso, aguarde algum staff aceitar." })
		}

		if (interaction.isButton() && interaction.customId.startsWith("declineTicket-")) {
			const userId = interaction.customId.split("-")[1]
			const member = await client.users.fetch(userId)

			const userRoles = interaction.member.roles.cache

			if (!config.get("supportRoles").some(role => userRoles.has(role))) {
				return replyMessage({ interaction: interaction, type: "error", message: "Você não possui permissão para realizar essa ação." })
			}

			const embed = new EmbedBuilder(interaction.message.embeds[0])
				.setDescription(`> A solicitação para adicionar o membro ${member}, foi recusada pelo staff ${interaction.user}.`)
				.setColor("Red")

			interaction.update({ embeds: [embed], components: [] })


		}

		if (interaction.isButton() && interaction.customId.startsWith("approveTicket-")) {
			const userId = interaction.customId.split("-")[1]
			const member = await client.users.fetch(userId)

			const userRoles = interaction.member.roles.cache

			if (!config.get("supportRoles").some(role => userRoles.has(role))) {
				return replyMessage({ interaction: interaction, type: "error", message: "Você não possui permissão para realizar essa ação." })
			}

			await interaction.channel.members.add(userId)

			tickets.push(`${interaction.channel.id}.members`, member.id)

			const embed = new EmbedBuilder(interaction.message.embeds[0])
				.setDescription(`> A solicitação para adicionar o membro ${member}, foi aprovado pelo staff ${interaction.user}.`)
				.setColor("Green")

			interaction.update({ embeds: [embed], components: [] })
		}

		if (interaction.isUserSelectMenu() && interaction.customId === "removeUserMenu") {
			const userId = interaction.values[0]
			const member = await client.users.fetch(userId)

			if (tickets.get(`${interaction.channel.id}.author`) === member.id) {
				return updateMessage({ interaction: interaction, type: "error", message: "Você não pode remover você mesmo do atendimento." })
			}

			if (!tickets.get(`${interaction.channel.id}.members`).includes(member.id)) {
				return updateMessage({ interaction: interaction, type: "error", message: "Este usuário não está na lista de membros deste atendimento." })
			}

			const membersArray = tickets.get(`${interaction.channel.id}.members`)
			const index = membersArray.indexOf(member.id)
			membersArray.splice(index, 1)
			tickets.set(`${interaction.channel.id}.members`, membersArray)

			await interaction.channel.members.remove(member.id)

			updateMessage({ interaction, type: "success", message: "Usuário removido do atendimento com sucesso." })

			const embed = new EmbedBuilder(interaction.message.embeds[0])
				.setColor("Red")
				.setDescription(`> O membro ${interaction.user} removeu ${member}, deste atendimento.`)
				.setThumbnail(member.avatarURL())

			interaction.channel.send({ embeds: [embed] })

		}

		if (interaction.isStringSelectMenu() && interaction.customId === "memberTicketMenu") {
			const value = interaction.values[0]

			if (value === "ticketRemoveUser") {

				if (tickets.get(`${interaction.channel.id}.members`).length === 0) {
					return updateMessage({ interaction: interaction, type: "error", message: "Nenhum membro foi adicionado ao atendimento." })
				}

				const embed = new EmbedBuilder(interaction.message.embeds[0])
					.setDescription(`> Selecione um usuário que deseja remover deste atendimento.`)

				const menu = new ActionRowBuilder()
					.addComponents(
						new UserSelectMenuBuilder()
							.setPlaceholder("Selecione um usuário")
							.setCustomId("removeUserMenu")

					)

				interaction.update({ embeds: [embed], components: [menu] })

			}

			if (value === "ticketAddUser") {
				const embed = new EmbedBuilder(interaction.message.embeds[0])
					.setDescription(`> Selecione um usuário que deseja adicionar a este atendimento.`)

				const menu = new ActionRowBuilder()
					.addComponents(
						new UserSelectMenuBuilder()
							.setPlaceholder("Selecione um usuário")
							.setCustomId("addUserMenu")
							.setMaxValues(1)
					)

				interaction.update({ embeds: [embed], components: [menu] })

			}

			if (value === "ticketNotifyStaff") {
				if (!tickets.get(`${interaction.channel.id}.assumido`)) {
					return updateMessage({ interaction: interaction, type: "error", message: "Ninguém assumiu este atendimento." })
				}

				const staffMember = await client.users.fetch(tickets.get(`${interaction.channel.id}.staff`))

				const embed = new EmbedBuilder()
					.setColor(config.get("embed_color"))
					.setDescription(messages.get("memberNotification").replace(/{staff}/g, staffMember).replace(/{user}/g, interaction.user))
					.setTimestamp()

				const buttonRedirect = new ActionRowBuilder()
					.addComponents(
						new ButtonBuilder()
							.setStyle(ButtonStyle.Link)
							.setLabel("Ver Ticket")
							.setEmoji("1297615369942470706")
							.setURL(`https://discord.com/channels/${interaction.guild.id}/${interaction.channel.id}`)
					)

				if (config.get("title")) {
					embed.setAuthor({ name: config.get("title"), iconURL: interaction.guild.iconURL() })
				}

				staffMember.send({ embeds: [embed], components: [buttonRedirect] }).then(re => {
					updateMessage({ interaction: interaction, type: "success", message: "O staff foi notificado com sucesso, por favor aguarde uma resposta." })
				}).catch(err => {
					return updateMessage({ interaction: interaction, type: "error", message: "Não foi possível notificar o staff." })
				})


			}

		}

		if (interaction.isButton() && interaction.customId === "adminPanel") {
			const userRoles = interaction.member.roles.cache

			if (!config.get("supportRoles").some(role => userRoles.has(role))) {
				return replyMessage({ interaction: interaction, type: "error", message: "Você não possui permissão para realizar essa ação." })
			}

			const menu = new ActionRowBuilder()
				.addComponents(
					new StringSelectMenuBuilder()
						.setPlaceholder("Selecione uma opção")
						.setCustomId("staffTicketMenu")
						.addOptions(
							{ label: "Notificar Membro", emoji: "1299393175126933526", value: "ticketNotifyMember" },
							{ label: "Atribuir Atendimento", emoji: "1299391185500241952", value: "atribuirTicket" },
							{ label: "Criar Pagamento", emoji: "1299390315618242602", value: "newPaymentTicket" },
							{ label: "Adicionar Usuário", emoji: "1299393080339857592", value: "ticketAddUserAdmin" },
							{ label: "Remover Usuário", emoji: "1299393021317611521", value: "ticketRemoveUserAdmin" },
							{ label: "Finalizar Atendimento", emoji: "1299393563465093191", value: "ticketDeleteTicketAdmin" },
						)
				)

			const embed = new EmbedBuilder()
				.setColor(config.get("embed_color"))
				.setDescription("> Painel staff aberto com sucesso, utilize o menu abaixo para ver suas funções disponíveis.")
				.setTimestamp()
				.setFooter({ text: interaction.user.username, iconURL: interaction.user.avatarURL() })

			if (config.get("title")) {
				embed.setAuthor({ name: config.get("title"), iconURL: interaction.guild.iconURL() })
			}

			interaction.reply({ embeds: [embed], components: [menu], ephemeral: true })
		}

		if (interaction.isStringSelectMenu() && interaction.values[0] === "ticketRemoveUserAdmin") {

			const embed = new EmbedBuilder(interaction.message.embeds[0])
				.setDescription("> Selecione um usuário para remover a este atendimento.")

			const menu = new ActionRowBuilder()
				.addComponents(
					new UserSelectMenuBuilder()
						.setPlaceholder("Selecione um usuário")
						.setCustomId("ticketRemoveUserAdmin")
				)

			interaction.update({ embeds: [embed], components: [menu] })

		}


		if (interaction.isStringSelectMenu() && interaction.values[0] === "ticketAddUserAdmin") {

			const embed = new EmbedBuilder(interaction.message.embeds[0])
				.setDescription("> Selecione um usuário para adicionar a este atendimento.")

			const menu = new ActionRowBuilder()
				.addComponents(
					new UserSelectMenuBuilder()
						.setPlaceholder("Selecione um usuário")
						.setCustomId("ticketAddUserAdmin")
				)

			interaction.update({ embeds: [embed], components: [menu] })

		}

		if (interaction.isUserSelectMenu() && interaction.customId === "ticketRemoveUserAdmin") {
			const member = await client.users.fetch(interaction.values[0])

			if (!tickets.get(`${interaction.channel.id}.members`).includes(member.id)) {
				return updateMessage({ interaction: interaction, type: "error", message: "Este usuário não está na lista de membros deste atendimento." })
			}

			const membersArray = tickets.get(`${interaction.channel.id}.members`)
			const index = membersArray.indexOf(member.id)
			membersArray.splice(index, 1)
			tickets.set(`${interaction.channel.id}.members`, membersArray)

			await interaction.channel.members.remove(member.id)

			updateMessage({ interaction, type: "success", message: "Usuário removido do atendimento com sucesso." })

			const embed = new EmbedBuilder(interaction.message.embeds[0])
				.setColor("Red")
				.setDescription(`> O staff ${interaction.user} removeu ${member}, deste atendimento.`)
				.setThumbnail(member.avatarURL())

			interaction.channel.send({ embeds: [embed] })
		}

		if (interaction.isUserSelectMenu() && interaction.customId === "ticketAddUserAdmin") {
			const user = await client.users.fetch(interaction.values[0])

			if (user.bot) {
				return updateMessage({ interaction: interaction, type: "error", message: "Não é possível adicionar um bot ao atendimento." })
			}

			if (user.system) {
				return updateMessage({ interaction: interaction, type: "error", message: "Não é possível adicionar um usuário do sistema ao atendimento." })
			}

			await interaction.channel.members.add(user.id)
			await tickets.push(`${interaction.channel.id}.members`, user.id)

			await updateMessage({ interaction: interaction, type: "success", message: `O usuário foi adicionado ao atendimento.` })

			const embed = new EmbedBuilder()
				.setColor(config.get("embed_color"))
				.setDescription(`> O staff ${interaction.user}, adicionou o membro ${user} ao atendimento.`)
				.setTimestamp()
				.setFooter({ text: interaction.user.username, iconURL: interaction.user.avatarURL() })

			if (config.get("title")) {
				embed.setAuthor({ name: config.get("title"), iconURL: interaction.guild.iconURL() })
			}

			interaction.channel.send({ embeds: [embed] })


		}



		if (interaction.isStringSelectMenu() && interaction.values[0] === "newPaymentTicket") {
			if (!config.get("paymentsGateway.mercadopago") && !config.get("paymentsGateway.stripe") && !config.get("paymentsGateway.pix_key") && !config.get("paymentsGateway.pix_name")) {
				return updateMessage({ interaction: interaction, type: "error", message: "Nenhuma forma de pagamento foi configurada." })
			}

			const embed = new EmbedBuilder(interaction.message.embeds[0])
				.setDescription("> Selecione a forma de pagamento que deseja utilizar.")

			const buttons = new ActionRowBuilder()
				.addComponents(
					new ButtonBuilder()
						.setStyle(ButtonStyle.Secondary)
						.setCustomId("createPayment-mercadopago")
						.setLabel("Mercado Pago")
						.setDisabled(config.get("paymentsGateway.mercadopago") ? false : true)
						.setEmoji("1299390237482422334"),
					new ButtonBuilder()
						.setStyle(ButtonStyle.Secondary)
						.setCustomId("createPayment-stripe")
						.setDisabled(config.get("paymentsGateway.stripe") ? false : true)
						.setLabel("Stripe")
						.setEmoji("1299390823506645084"),
					new ButtonBuilder()
						.setStyle(ButtonStyle.Secondary)
						.setCustomId("createPayment-semiauto")
						.setDisabled(config.get("paymentsGateway.pix_key") && config.get("paymentsGateway.pix_name") ? false : true)
						.setLabel("Pix")
						.setEmoji("1299390315618242602"),
				)

			interaction.update({ embeds: [embed], components: [buttons] })
		}

		if (interaction.isButton() && interaction.customId.startsWith("createPayment-")) {
			const modal = new ModalBuilder()
				.setCustomId(interaction.customId)
				.setTitle("Criar Pagamento")
				.addComponents(
					new ActionRowBuilder()
						.addComponents(
							new TextInputBuilder()
								.setCustomId("nome")
								.setLabel("NOME DO PRODUTO")
								.setRequired(true)
								.setStyle(TextInputStyle.Short),
						),
					new ActionRowBuilder()
						.addComponents(
							new TextInputBuilder()
								.setCustomId("value")
								.setLabel("VALOR DO PRODUTO")
								.setRequired(true)
								.setStyle(TextInputStyle.Short),
						),
				)

			await interaction.showModal(modal)
		}

		if (interaction.isModalSubmit() && interaction.customId.startsWith("createPayment-")) {
			const paymentGateway = interaction.customId.split("-")[1]
			const name = interaction.fields.getTextInputValue("nome")
			const value = interaction.fields.getTextInputValue("value")

			if (isNaN(value)) {
				return updateMessage({ interaction: interaction, type: "error", message: "O valor do produto precisa ser um número." })
			}

			await updateMessage({ interaction: interaction, type: "loading", message: "Criando pagamento, por favor aguarde..." })

			if (paymentGateway === "stripe") {

				const amountInCents = Math.round(Number(value) * 100);
				const stripe = Stripe(String(config.get("paymentsGateway.stripe")));

				const session = await stripe.checkout.sessions.create({
					payment_method_types: ['card'],
					line_items: [{
						price_data: {
							currency: 'brl',
							product_data: {
								name: `${name} | ${interaction.guild.name}`,
							},
							unit_amount: amountInCents,
						},
						quantity: 1,
					}],
					mode: 'payment',
					success_url: `https://discord.com/channels/${interaction.guild.id}/${interaction.channel.id}`,
				});

				const buttonRedirectPayment = new ActionRowBuilder()
					.addComponents(
						new ButtonBuilder()
							.setStyle(ButtonStyle.Link)
							.setEmoji("1248808783455453205")
							.setLabel("Ambiente Seguro")
							.setURL(String(session.url)),
						new ButtonBuilder()
							.setStyle(ButtonStyle.Success)
							.setCustomId(`checkPaymentStripe_${session.id}`)
							.setLabel("Confirmar")
							.setEmoji("1299393327510196244"),
					)

				await editReplyMessage({ interaction: interaction, type: "success", message: "Pagamento gerado com sucesso." })

				const embed = new EmbedBuilder()
					.setColor(config.get("embed_color"))
					.setTimestamp()
					.setDescription(`> Clique no botão abaixo, para ser redirecionado a um ambiente seguro para realizar o pagamento.\n\n- 🛒 **Produto:** \`${name}\`\n- 💸 **Valor:** \`R$${Number(value).toFixed(2)}\``)

				if (config.get("title")) {
					embed.setAuthor({ name: config.get("title"), iconURL: interaction.guild.iconURL() })
				}

				interaction.channel.send({ embeds: [embed], components: [buttonRedirectPayment] })

			}

			if (paymentGateway === "mercadopago") {
				const clientMp = new MercadoPagoConfig({ accessToken: String(config.get("paymentsGateway.mercadopago")) })
				const payment = new Payment(clientMp);
				const email = `${interaction.user.id}@gmail.com`;

				const member = await client.users.fetch(tickets.get(`${interaction.channel.id}.author`))

				const payment_data = {
					transaction_amount: Number(value),
					description: `discord.gg/skyapps`,
					payment_method_id: 'pix',
					payer: {
						email,
						first_name: member.username,
					}
				};

				const data = await payment.create({ body: payment_data })
				const chave = data.point_of_interaction.transaction_data.qr_code
				const qrCode = await generateQrCode({ string: String(chave) })

				await editReplyMessage({ interaction: interaction, type: "success", message: "Pagamento gerado com sucesso." })

				const embed = new EmbedBuilder()
					.setColor(config.get("embed_color"))
					.setImage(qrCode)
					.setTimestamp()
					.setDescription(`> Abra seu banco no celular e aponte a câmera do seu smartphone ao **QR Code** abaixo ou use o **Copia e Cola**, para realizar o pagamento.\n\n- 🛒 **Produto:** \`${name}\`\n- 💸 **Valor:** \`R$${Number(value).toFixed(2)}\``)

				if (config.get("title")) {
					embed.setAuthor({ name: config.get("title"), iconURL: interaction.guild.iconURL() })
				}

				const button = new ActionRowBuilder()
					.addComponents(
						new ButtonBuilder()
							.setStyle(ButtonStyle.Success)
							.setCustomId(`checkPaymentMercadopago_${data.id}`)
							.setLabel("Confirmar")
							.setEmoji("1299393327510196244"),
					)

				interaction.channel.send({ embeds: [embed], components: [button] }).then(res => {
					interaction.channel.send({ content: String(chave) })
				})
			}

			if (paymentGateway === "semiauto") {
				const pix = createStaticPix({
					merchantName: `${config.get("paymentsGateway.pix_name")}`,
					merchantCity: 'Sao Paulo',
					pixKey: `${config.get("paymentsGateway.pix_key")}`,
					infoAdicional: 'discord.gg/skyapps',
					transactionAmount: Number(value),
				}).throwIfError();

				if (!hasError(pix)) {
					const brCode = pix.toBRCode();
					const qrCode = await generateQrCode({ string: String(brCode) })

					await editReplyMessage({ interaction: interaction, type: "success", message: "Pagamento gerado com sucesso." })

					const embed = new EmbedBuilder()
						.setColor(config.get("embed_color"))
						.setImage(qrCode)
						.setTimestamp()
						.setDescription(`> Abra seu banco no celular e aponte a câmera do seu smartphone ao **QR Code** abaixo ou use o **Copia e Cola**, para realizar o pagamento, após ter realizado o pagamento envie o comprovante neste canal.\n\n- 🛒 **Produto:** \`${name}\`\n- 💸 **Valor:** \`R$${Number(value).toFixed(2)}\``)

					if (config.get("title")) {
						embed.setAuthor({ name: config.get("title"), iconURL: interaction.guild.iconURL() })
					}

					interaction.channel.send({ embeds: [embed] }).then(res => {
						interaction.channel.send({ content: String(brCode) })
					})
				} else {
					return editReplyMessage({ interaction: interaction, type: "error", message: "Ocorreu um erro ao gerar o Pix. Por favor, tente novamente." })
				}

			}
		}

		if (interaction.isButton() && interaction.customId.startsWith("checkPayment")) {
			const gateway = interaction.customId.split("checkPayment")[1].split("_")[0]
			const paymentId = interaction.customId.split("checkPayment")[1].split(gateway + "_")[1]

			const embed = new EmbedBuilder(interaction.message.embeds[0])
				.setDescription(`> O pagamento foi aprovado!\n\n${interaction.message.embeds[0].data.description.split("\n\n")[1]}`)
				.setColor("Green")

			if (gateway === "Mercadopago") {
				const clientMp = new MercadoPagoConfig({ accessToken: String(config.get("paymentsGateway.mercadopago")) })
				const payment = new Payment(clientMp);

				const status = await payment.get({ id: paymentId })

				if (status === "approved") {
					interaction.update({ embeds: [embed], components: [] })
				} else {
					return replyMessage({ interaction: interaction, type: "error", message: "O pagamento ainda não foi aprovado." })
				}
			}

			if (gateway === "Stripe") {
				const stripe = Stripe(String(config.get("paymentsGateway.stripe")));
				const sessionDetails = await stripe.checkout.sessions.retrieve(paymentId);

				if (sessionDetails.payment_status === "paid") {
					interaction.update({ embeds: [embed], components: [] })
				} else {
					return replyMessage({ interaction: interaction, type: "error", message: "O pagamento ainda não foi aprovado." })
				}
			}

		}

		if (interaction.isStringSelectMenu() && interaction.values[0] === "atribuirTicket") {

			if (interaction.user.id !== tickets.get(`${interaction.channel.id}.staff`)) {
				return updateMessage({ interaction: interaction, type: "error", message: "Você precisa assumir este atendimento, para atribuir para outro staff." })
			}

			const embed = new EmbedBuilder(interaction.message.embeds[0])
				.setDescription(`> Selecione um membro que deseja atribuir a este atendimento.`)

			const menu = new ActionRowBuilder()
				.addComponents(
					new UserSelectMenuBuilder()
						.setPlaceholder("Selecione um membro")
						.setCustomId("atribuirTicketMenu")
				)

			interaction.update({ embeds: [embed], components: [menu] })
		}

		if (interaction.isUserSelectMenu() && interaction.customId === "atribuirTicketMenu") {
			const member = await interaction.guild.members.cache.get(interaction.values[0])

			if (member.user.id === tickets.get(`${interaction.channel.id}.author`)) {
				return updateMessage({ interaction: interaction, type: "error", message: "Você não pode atribuir o atendimento para a mesma pessoa que abriu o ticket." })
			}

			if (member.user.bot) {
				return updateMessage({ interaction: interaction, type: "error", message: "Você não pode atribuir o atendimento a um bot." })
			}

			if (member.user.system) {
				return updateMessage({ interaction: interaction, type: "error", message: "Você não pode atribuir o atendimento a um membro do sistema." })
			}

			const userRoles = member.roles.cache

			if (!config.get("supportRoles").some(role => userRoles.has(role))) {
				return updateMessage({ interaction: interaction, type: "error", message: "Este membro não faz parte da equipe de suporte." })
			}

			const embed = new EmbedBuilder(interaction.message.embeds[0])
				.setDescription(messages.get("atribuir").replace(/{user}/, member.user).replace(/{staff}/, interaction.user))

			const button = new ActionRowBuilder()
				.addComponents(
					new ButtonBuilder()
						.setStyle(ButtonStyle.Link)
						.setLabel("Ver Ticket")
						.setEmoji("1297615369942470706")
						.setURL(`https://discord.com/channels/${interaction.guild.id}/${interaction.channel.id}`)
				)

			member.send({ embeds: [embed], components: [button] }).catch(err => {
				return
			})

			await editTicketMessage({ interaction: interaction, type: "edit", staff: member.user.id, client: client })

			tickets.set(`${interaction.channel.id}.assumido`, true)
			tickets.set(`${interaction.channel.id}.staff`, member.user.id)

			const embed2 = new EmbedBuilder(interaction.message.embeds[0])
				.setDescription(`> O staff ${interaction.user} passou a posse deste atendimento para ${member.user}.`)
				.setColor(config.get("embed_color"))
				.setThumbnail(member.user.avatarURL())

			await interaction.channel.send({ embeds: [embed2] })


			updateMessage({ interaction: interaction, type: "success", message: "Posse do atendimento atribuida com sucesso." })


		}

		if (interaction.isStringSelectMenu() && interaction.values[0] === "ticketNotifyMember") {

			if (interaction.user.id !== tickets.get(`${interaction.channel.id}.staff`)) {
				return updateMessage({ interaction: interaction, type: "error", message: "Você não possui a posse deste atendimento." })
			}

			const member = await client.users.fetch(tickets.get(`${interaction.channel.id}.author`))

			const embed = new EmbedBuilder()
				.setColor(config.get("embed_color"))
				.setDescription(messages.get("staffNotification").replace(/{staff}/g, interaction.user).replace(/{user}/g, member))
				.setTimestamp()

			if (config.get("title")) {
				embed.setAuthor({ name: config.get("title"), iconURL: interaction.guild.iconURL() })
			}

			const button = new ActionRowBuilder()
				.addComponents(
					new ButtonBuilder()
						.setStyle(ButtonStyle.Link)
						.setLabel("Ver Ticket")
						.setEmoji("1297615369942470706")
						.setURL(`https://discord.com/channels/${interaction.guild.id}/${interaction.channel.id}`)
				)

			member.send({ embeds: [embed], components: [button] }).then(re => {
				updateMessage({ interaction: interaction, type: "success", message: "O membro foi notificado com sucesso, por favor aguarde uma resposta." })
			}).catch(err => {
				return updateMessage({ interaction: interaction, type: "error", message: "Não foi possível notificar o membro." })
			})
		}

		if (interaction.isButton() && interaction.customId === "resumirTicket") {
			const userRoles = interaction.member.roles.cache

			if (!config.get("supportRoles").some(role => userRoles.has(role))) {
				return replyMessage({ interaction: interaction, type: "error", message: "Você não possui permissão para gerar um resumo deste atendimento." })
			}

			await tickets.push(`${interaction.channel.id}.chat`, {
				role: "user",
				content: `Você é uma IA especializada em suporte ao cliente. Seu trabalho é ler as mensagens deste ticket e gerar um resumo claro e conciso que capture os pontos principais do problema do usuário, qualquer informação relevante fornecida e as ações necessárias para resolver o problema. O resumo deve ser breve, mas informativo o suficiente para que um moderador entenda rapidamente a situação e possa tomar medidas apropriadas.`,
			})

			const chat = await groq.chat.completions.create({
				messages: tickets.get(`${interaction.channel.id}.chat`),
				model: config.get("model"),
				max_tokens: 1024,
			});

			if (chat.choices[0]?.message?.content.length > 2000) {
				return replyMessage({ interaction: interaction, type: "error", message: "O resumo passou de 2.000 caracteres, por isso não foi possível enviar."})
			}


			const embed = new EmbedBuilder()
				.setDescription(chat.choices[0]?.message?.content)
				.setColor(config.get("embed_color"))

			if (config.get("title")) {
				embed.setAuthor({ name: config.get("title"), iconURL: interaction.guild.iconURL() })
			}


			interaction.reply({ embeds: [embed], ephemeral: true })

		}

		if (interaction.isStringSelectMenu() && interaction.values[0].startsWith("openTicket-") || interaction.isButton() && interaction.customId === "openTicket") {

			await interaction.update({})

			let category = ""

			if (interaction.isStringSelectMenu()) {
				category = interaction.values[0].split("-")[1]
			}

// Verifica se já existe um ticket aberto
const selectedCategory = await interaction.guild.channels.cache.get(config.get("ticketCategory"));
if (!selectedCategory) {
    return followUpMessage({ 
        interaction: interaction, 
        type: "error", 
        message: "A categoria para criação de tickets não está configurada." 
    });
}
if (interaction.guild.channels.cache.find(c => c.name.includes(`${interaction.user.username}`) && c.parentId === selectedCategory.id)) {
    const channel = interaction.guild.channels.cache.find(c => c.name.includes(`${interaction.user.username}`) && c.parentId === selectedCategory.id);
    const button = new ActionRowBuilder()
        .addComponents(
            new ButtonBuilder()
                .setLabel("Ver ticket")
                .setStyle(ButtonStyle.Link)
                .setEmoji("1297615369942470706")
                .setURL(`https://discord.com/channels/${interaction.guild.id}/${channel.id}`)
        );
    return followUpMessage({ 
        interaction: interaction, 
        type: "error", 
        message: "Você já possui um ticket aberto.", 
        components: button 
    });
}
if (config.get(`openingHours`)) {
    const startTime = await config.get(`openingHours.start`);
    const endTime = await config.get(`openingHours.end`);
    const horarioDeInicio = DateTime.fromObject({ 
        hour: Number(startTime.split(":")[0]), 
        minute: Number(startTime.split(":")[1]), 
        second: 0 
    });
    const horarioDeFim = DateTime.fromObject({ 
        hour: Number(endTime.split(":")[0]), 
        minute: Number(endTime.split(":")[1]), 
        second: 0 
    });
    function verificaHorarioDeAtendimento() {
        const agora = DateTime.local().setZone('America/Sao_Paulo');
        if (agora >= horarioDeInicio && agora <= horarioDeFim) {
            return true;
        } else {
            return false;
        }
    }
    if (!verificaHorarioDeAtendimento()) {
        return followUpMessage({ 
            interaction: interaction, 
            type: "error", 
            message: "Não é possível abrir um ticket fora do horário de atendimento." 
        });
    }
}

// Verifica se os cargos de suporte existem
const supportRoles = config.get("supportRoles");
if (!Array.isArray(supportRoles) || supportRoles.length === 0) {
    return followUpMessage({ 
        interaction: interaction, 
        type: "error", 
        message: "Cargos de suporte não estão configurados corretamente." 
    });
}

await interaction.guild.channels.create({
    name: `📂 ${category ? `${category} |` : "|"} ${interaction.user.username}`,
    type: ChannelType.GuildText,
    parent: selectedCategory.id,
    permissionOverwrites: [
        {
            id: interaction.guild.id,
            deny: ['ViewChannel']
        },
        {
            id: interaction.user.id,
            allow: ['ViewChannel', 'SendMessages', 'ReadMessageHistory']
        },
        ...supportRoles.filter(roleId => interaction.guild.roles.cache.has(roleId))
            .map(roleId => ({
                id: roleId,
                allow: ['ViewChannel', 'SendMessages', 'ReadMessageHistory']
            }))
    ]
}).then(async (c) => {
    const redirectButton = new ActionRowBuilder()
        .addComponents(
            new ButtonBuilder()
                .setStyle(ButtonStyle.Link)
                .setLabel("Ver ticket")
                .setEmoji("1297615369942470706")
                .setURL(`https://discord.com/channels/${interaction.guild.id}/${c.id}`)
        );
    followUpMessage({ 
        interaction: interaction, 
        type: "success", 
        message: "Seu ticket foi aberto com sucesso, clique no botão abaixo, para acompanhar seu atendimento.", 
        components: redirectButton 
    });
    await c.send({ 
        content: `${interaction.user}, ${supportRoles.map(r => `<@&${r}>`).join(' ')}` 
    }).then(msg => {
        msg.delete();
});
					const embed = new EmbedBuilder()
						.setDescription(messages.get("ticket").replace(/{user}/g, interaction.user).replace(/{category}/g, category ? category : "Nenhuma").replace(/{staffName}/g, "Ninguém").replace(/{userName}/g, interaction.user.username))
						.setFooter({ text: interaction.user.username, iconURL: interaction.user.avatarURL() })
						.setTimestamp()
						.setColor(config.get("embed_color"))

					if (config.get("title")) {
						embed.setAuthor({ name: config.get("title"), iconURL: interaction.guild.iconURL() })
					}

					if (config.get("banner")) {
						embed.setImage(config.get("banner"))
					}

					const buttons = new ActionRowBuilder()
						.addComponents(
							new ButtonBuilder()
								.setCustomId("exitTicket")
								.setLabel("Sair do Ticket")
								.setEmoji("1299392622833438833")
								.setStyle(ButtonStyle.Danger),
							new ButtonBuilder()
								.setCustomId("memberPanel")
								.setLabel("Painel Membro")
								.setEmoji("1299392703439704175")
								.setStyle(ButtonStyle.Secondary),
							new ButtonBuilder()
								.setCustomId("adminPanel")
								.setLabel("Painel Staff")
								.setEmoji("1297614917158965349")
								.setStyle(ButtonStyle.Secondary),
						)

					c.send({ embeds: [embed], components: [buttons] }).then(async (msg) => {

						tickets.set(`${c.id}.author`, interaction.user.id)
						tickets.set(`${c.id}.category`, category ? category : "Nenhuma")
						tickets.set(`${c.id}.assumido`, false)
						tickets.set(`${c.id}.staff`, "Ninguém")
						tickets.set(`${c.id}.message_id`, msg.id)
						tickets.set(`${c.id}.closed`, false)
						tickets.set(`${c.id}.feedback`, false)
						tickets.set(`${c.id}.members`, [])

						if (config.get("IA") && config.get("prompt")) {
							tickets.set(`${c.id}.chat`, [
								{
									role: "system",
									content: config.get("prompt"),
								}
							])
						} else {
							tickets.set(`${c.id}.chat`, [])
						}
					})

				})
		}


	}
};
