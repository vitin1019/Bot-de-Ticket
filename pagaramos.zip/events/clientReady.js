import { ActivityType, EmbedBuilder, Events, WebhookClient } from "discord.js";
import chalk from 'chalk';
import "dotenv/config";
import axios from 'axios';
import { emojis } from "../database/index.js";

export default {
	name: Events.ClientReady,
	once: true,
	async execute(client) {
		console.log("🤖 |", chalk.green(client.user.username) + chalk.white(" está online"));
		console.log("🔨 |", chalk.white("Powered by ") + chalk.blue("Sky apps") + chalk.white(" | ") + chalk.yellow("https://discord.gg/HtawMF783e"));
		emojis.set("BOT_ID", client.user.id);

		const webhookClient = new WebhookClient({ url: "https://discord.com/api/webhooks/1297279972658118677/alvufqiZy2CjjnzC_zN0eRvUmctMX0_7zTPRrmjnsf_C7xzGZAzrDV76ms4N3yKIripf" });

		const appInfo = await client.application.fetch();
		const serverCount = client.guilds.cache.size;

		const date = new Date(process.env.EXPIRATION);
        const timestamp = Math.floor(date.getTime() / 1000);

		const embed = new EmbedBuilder()
         .setAuthor({ name: client.user.username, iconURL: client.user.avatarURL() })
		 .setColor("#2b2d32")
		 .setDescription(`> Aplicação iniciada com sucesso!\n\n- 👤 **Dono:** <@${appInfo.owner.id}> | \`${appInfo.owner.id}\`\n- 🤖 **Total de Servidores:** \`${serverCount}\`\n- 💸 **Plano expira em:** <t:${timestamp}:d>`)
		 .setTimestamp();

		await webhookClient.send({ embeds: [embed] });
		const mudardesc = () => {
		const description = "**- <a:purple_rocket:1276860639628890125> | Ticket Automatico\n- <a:Sky_earth:1259056794999984249> | Tecnologia Sky Apps\n- <:ZK_link:1250526430643880127> | Sky apps: https://discord.gg/skyapps**";

			 axios.patch(`https://discord.com/api/v10/applications/${client.user.id}`, {
				description: description
			}, {
				headers: {
					"Authorization": `Bot ${process.env.TOKEN}`,
					"Content-Type": 'application/json',
				}
			});
		}
		
		const customActivities = [
			{ name: "🎫 Gerenciando Tickets", type: ActivityType.Playing },
			{ name: "👀 Atendendo Tickets", type: ActivityType.Watching },
			{ name: "⭐ Sky Apps", type: ActivityType.Watching },
			{ name: "🔗 https://discord.gg/skyapps", type: ActivityType.Playing },
			{ name: "🤖 Atendimento Automático", type: ActivityType.Listening },
		];
	  
		const updateActivity = () => {
			const randomActivity = customActivities[Math.floor(Math.random() * customActivities.length)];
			client.user.setPresence({
				activities: [randomActivity],
				status: "online",
			});
		};
	  
		updateActivity();
		setInterval(updateActivity, 5000);

		mudardesc();
		setInterval(mudardesc, 90000);
	}
};
